// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import promise from 'es6-promise'
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
// import './mock'

import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import '@/assets/css/theme/f5222d/index.css' // 换肤版本0000ff css
import '@/assets/css/theme/fa541c/index.css' // 换肤版本008000 css
import '@/assets/css/theme/faad14/index.css' // 换肤版本fa4f52 css
import '@/assets/css/theme/13c2c2/index.css' // 换肤版本20a0ff css
import '@/assets/css/theme/52c41a/index.css' // 换肤版本00a597 css
import '@/assets/css/theme/1890ff/index.css' // 换肤版本fa4f52 css
import '@/assets/css/theme/2f54eb/index.css' // 换肤版本20a0ff css
import '@/assets/css/theme/722ed1/index.css' // 换肤版本00a597 css
import '@/assets/style/sass/example.scss'
import '@/assets/_common.scss'
import '@/utils/portal'
import '@/utils/svgIcon'
import { setToken } from '@/utils/storage/cookies'
import * as filters from '@/utils/filters'
const token = window.location.search.split('&')[0].split('=')[1]
if (token) {
  setToken(token) // global filters
}
// register global utility filters.
Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

Vue.config.productionTip = false

Vue.use(ElementUI)
/* eslint-disable no-new */
promise.polyfill()

new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<App/>'
})
