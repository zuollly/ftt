<template>
  <div>
    注册
  </div>
</template>
