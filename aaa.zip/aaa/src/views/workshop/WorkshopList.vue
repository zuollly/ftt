<template>
  <div class="courseListWrapper">
    <div class="ftp-body" v-loading="loadingCourse">
      <div class="ftp-header">
        <el-button type="primary" @click="addGroup" icon="el-icon-plus">添加</el-button>
      </div>
      <el-table
        :data="groupList"
        style="width: 100%"
        ref="multipleTable"
        tooltip-effect="dark"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column label="工作室名称" width="350" show-overflow-tooltip resizable>
          <template slot-scope="scope">
            <a @click="jumptoProject(scope.row)">{{scope.row.groupName}}</a>
          </template>
        </el-table-column>
        <el-table-column label="工作室简介" show-overflow-tooltip resizable>
          <template slot-scope="scope">
            <span v-html="scope.row.groupIntroduction"></span>
          </template>
        </el-table-column>
        <el-table-column label="主持人" width="140" show-overflow-tooltip resizable>
          <template slot-scope="scope">{{scope.row.adminUserName}}</template>
        </el-table-column>
        <el-table-column label="是否支持申请" width="140" show-overflow-tooltip resizable>
          <template slot-scope="scope">{{scope.row.isSupportApply | filterStatus}}</template>
        </el-table-column>
        <el-table-column label="操作" show-overflow-tooltip resizable>
          <template slot-scope="scope">
            <!-- <el-button size="small" @click="viewMember(scope.row)">坊内成员</el-button>
            <el-button size="small" @click="viewActivity(scope.row)">坊内活动</el-button> -->
            <el-button size="small" @click="editGroup(scope.row)">编辑</el-button>
            <el-button size="small" @click="deleteRow(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="ftp-footer">
        <el-button @click="deleteAll()" type="info" size="medium" plain>批量删除</el-button>
      </div>
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pageObj.currentPage"
        :page-sizes="[5, 10, 20, 40]"
        :page-size="pageObj.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pageObj.total"
      ></el-pagination>
    </div>
    <WorkshopListAdd
       v-if="workShopFlag"
      :dialogVisibleAdd="dialogVisibleAdd"
      :opeType="opeType"
      :itemContent="itemContent"
      @cancel="cancel"
      @save="save"
    ></WorkshopListAdd>
    <el-dialog
      title="坊内成员"
      :visible.sync="memberDialog"
      width="45%">
      <el-row :gutter="18">
        <el-col :span="6" v-for="(element,index) of memberList" :key="index">
          <div class="text-center">
              <img style="width: 150px; height: 150px" :src="element.avatar">
            </div>
            <div class="caption text-center">
              <h5>{{element.realname}}</h5>
              <p v-if="element.schoolName" style="min-height: 20px" class="text-muted over-style">{{element.schoolName}}</p>
              <p class="noSchool" v-if="!element.schoolName">暂无学校</p>
              <p class="text-muted">角色：{{element.roleCode=='GROUP_LEADER'?'坊主':element.roleCode=='GROUP_DEPUTY_LEADER'?'副坊主':'成员'}}</p>
            </div>
        </el-col>
        <el-col class="list-group-item" v-if="!memberList || memberList.length === 0">
            暂无数据
        </el-col>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button @click="memberDialog = false">取 消</el-button>
        <el-button type="primary" @click="memberDialog = false">确 定</el-button>
      </span>
    </el-dialog>
    <el-dialog
      title="坊内成员"
      :visible.sync="activityDialog"
      width="45%">
      <el-row :gutter="18" class="pl-2 pr-2">
        <el-table :data="activityList" style="width: 100%">
          <el-table-column
            prop="activityName"
            label="活动名称">
          </el-table-column>
        </el-table>
      </el-row>
      <el-pagination
      v-if="activityList && activityList.length"
        @size-change="handleActSizeChange"
        @current-change="handleActivityChange"
        :current-page="acObj.pageCurrent"
        :page-size="acObj.pageSize"
        :total="acObj.total"
      ></el-pagination>
      <span slot="footer" class="dialog-footer">
        <el-button @click="activityDialog = false">取 消</el-button>
        <el-button type="primary" @click="activityDialog = false">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { fetchGroupPage, deleteGroup, fetchActivityFromGroup } from '@/api/workshop.js'
import { fetchProjectMemberPage } from '@/api/member.js'
import { mapGetters } from 'vuex'
export default {
  name: 'WorkshopList',
  components: {
    WorkshopListAdd: () => import('./modules/WorkshopListAdd.vue')
  },
  mixins: [],
  data() {
    return {
      groupList: [],
      opeType: '',
      itemContent: {},
      multipleSelection: [],
      workShopFlag: false,
      dialogVisibleAdd: false, // 课程基本信息
      loadingCourse: true,
      memberDialog: false,
      activityDialog: false,
      memberList: [],
      activityList: [],
      pageObj: {
        currentPage: 1,
        pageSize: 10,
        total: 0
      },
      acObj: {
        pageCurrent: 1,
        pageSize: 10,
        total: 0
      },
      curItem: {}
    }
  },
  props: [],
  computed: {
    ...mapGetters([
      'appConfig'
    ])
  },
  watch: {},
  methods: {
    queryProjectMemberPage(roleScopeId) {
      const data = {
        roleScopeId: roleScopeId
      }
      fetchProjectMemberPage(data).then(res => {
        console.log(res)
        this.memberList = res.data.result.list
      })
    },
    queryProjectActivityPage() {
      const data = {
        groupId: this.curItem.id,
        pageCurrent: this.acObj.pageCurrent,
        pageSize: this.acObj.pageSize
      }
      fetchActivityFromGroup(data).then(res => {
        console.log(res)
        this.activityList = res.data.result ? res.data.result.records : []
        this.acObj.total = res.data.result ? res.data.result.total : 0
      })
    },
    jumptoProject(item) {
      console.log(item, this.appConfig)
      window.open(`${this.appConfig.app_homePage}/#/workshop/workshop-index/${item.id}/${item.projectId}`)
      // http://yx.nercel.cn/#/workshop/workshop-index/f85e75199090d15b5cbb5c2192cbac5d/d5a7bb32a62cc1b8c4df9ed4d23a3b61
    },
    viewMember(item) {
      this.memberDialog = true
      this.memberList = []
      this.queryProjectMemberPage(item.id)
    },
    viewActivity(item) {
      this.curItem = item
      this.activityDialog = true
      this.activityList = []
      this.queryProjectActivityPage()
    },
    // 添加课程基本信息
    addGroup() {
      this.opeType = 'add'
      this.itemContent = {}
      this.workShopFlag = true
      this.dialogVisibleAdd = true
    },
    editGroup(item) {
      this.opeType = 'edit'
      console.log(item, 'edit')
      this.itemContent = item
      this.workShopFlag = true
      this.dialogVisibleAdd = true
    },
    handleCurrentChange(val) {
      // 选择分页
      this.loading = true
      this.pageObj.currentPage = val
      this.queryGroupList()
    },
    handleSizeChange(val) {
      this.loading = true
      this.pageObj.pageSize = val
      this.queryGroupList()
    },
    handleActivityChange(val) {
      // 选择分页
      this.loading = true
      this.acObj.pageCurrent = val
      this.queryProjectActivityPage()
    },
    handleActSizeChange(val) {
      this.loading = true
      this.acObj.pageSize = val
      this.queryProjectActivityPage()
    },
    cancel() {
      this.workShopFlag = false
      this.dialogVisibleAdd = false
    },
    // 课程基本信息
    save() {
      this.queryGroupList()
      this.workShopFlag = false
      this.dialogVisibleAdd = false
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    deleteRow(item) {
      this.$confirm('确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          deleteGroup([item.id]).then(res => {
            if (res.data.code === 200) {
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
              this.queryGroupList()
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    deleteAll() {
      console.log(this.multipleSelection, '---')
      if (this.multipleSelection.length <= 0) {
        this.$message({
          type: 'warning',
          message: '请选择一条要删除的数据!'
        })
        return
      }
      const ids = this.multipleSelection.map(ele => {
        return ele.id
      })
      this.$confirm('确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          deleteGroup(ids).then(res => {
            if (res.data.code === 200) {
              this.$message({
                type: 'success',
                message: '删除成功!'
              })
              this.queryGroupList()
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    queryGroupList() {
      const data = {
        pageCurrent: this.pageObj.currentPage,
        pageSize: this.pageObj.pageSize
      }
      fetchGroupPage(data)
        .then(res => {
          this.loadingCourse = false
          console.log(res, 9)
          this.groupList = res.data.result ? res.data.result : []
          this.pageObj.total = res.data.result.total
          this.workShopFlag = false
          this.dialogVisibleAdd = false
        })
        .catch(error => {
          console.error(error)
        })
    }
  },
  filters: {
    filterStatus(val) {
      let text = ''
      switch (val) {
        case 1:
          text = '支持'
          break
        case 0:
          text = '不支持'
          break
        default:
          text = '未知'
      }
      return text
    }
  },
  mounted() {
    this.queryGroupList()
  }
}
</script>

<style scoped lang='scss'>
.courseListWrapper {
  // min-height: 100%;
  .ftp-body {
    background: #fff;
    position: relative;
    width: 100%;
    // border: 1px solid #e7ecf3;
    border-bottom: none;
    min-height: 100%;
    .ftp-header {
      padding: 16px 24px;
      border-bottom: 1px dashed #e7ecf3;
    }
    .ftp-footer {
      width: 100%;
      padding: 32px 24px;
      overflow: hidden;
      display: flex;
      justify-content: space-between;
    }
  }
   /deep/ .has-gutter th{
    background: #e5e5e5;
    color: black;
  }
}
</style>
