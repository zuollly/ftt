<template>
  <el-upload
    class="avatar-uploader"
    action="http://yx.nercel.cn/msapi/zuul/tool/file/upload"
    name="multipartFile"
    :headers="headers"
    :show-file-list="false"
    :on-success="handleAvatarSuccess"
    :before-upload="beforeAvatarUpload">
    <img v-if="imageUrl" :src="imageUrl" class="avatar">
    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
  </el-upload>
</template>

<script>
import { getToken } from '@/utils/storage/cookies'
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      // imageUrl: 'imageUrl',
      headers: {
        'enctype': 'multipart/form-data',
        'Authorization': `Bearer ${getToken()}`
      }
    }
  },
  computed: {
    ...mapGetters([
      'appConfig'
    ])
  },
  props: ['imageUrl', 'imgType'],
  methods: {
    handleAvatarSuccess(res, file) {
      // this.imageUrl = URL.createObjectURL(file.raw)
      if (this.imgType === 'cover') {
        this.$emit('getImg', file.response.result.fileUrl)
      }
      if (this.imgType === 'logo') {
        this.$emit('getLogoImg', file.response.result.fileUrl)
      }
      console.log(file, this.imageUrl, 'imageUrl--')
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === 'image/jpeg'
      const isLt2M = file.size / 1024 / 1024 < 2

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!')
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!')
      }
      return isJPG && isLt2M
    }
  },
  mounted() {
    console.log(getToken())
  }
}
</script>
<style scoped lang='scss'>
  /deep/ .el-upload {
    border: 1px dashed #d9d9d9!important;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  /deep/ .avatar-uploader{
    /deep/ .el-upload:hover {
      border-color: #409EFF!important;
    }
  }
  /deep/ .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 150px;
    height: 150px;
    line-height: 150px!important;
    text-align: center;
  }
  /deep/ .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
