<template>
  <el-dialog
    :title="opeType === 'add'? '新建工作坊':'编辑工作坊'"
    :visible.sync="dialogVisibleAdd"
    width="60%"
    :before-close="cancel">
    <el-form ref="formAdd" :model="formAdd" label-width="180px">
      <!-- <el-form-item label="区域类型">
        <el-select v-model="formAdd.groupAreaType" placeholder="请选择">
          <el-option label="校级工作坊" value="0"></el-option>
          <el-option label="区县级" value="1"></el-option>
          <el-option label="市级" value="2"></el-option>
          <el-option label="省级" value="3"></el-option>
        </el-select>
      </el-form-item> -->
      <el-form-item label="工作坊名称">
        <el-input class="wid50" v-model="formAdd.groupName"></el-input>
      </el-form-item>
      <el-form-item label="工作坊简介">
        <el-input class="wid50" v-model="formAdd.groupIntroduction"></el-input>
      </el-form-item>
      <el-form-item label="设置坊主">
        <span>{{setleaderInfo.ucName}}</span>
        <span v-if="opeType=='edit' && !setleaderInfo.ucName">{{formAdd.adminUserName}}</span>
        <el-button type="text" @click="chooseLeader">设置坊主</el-button>
      </el-form-item>
      <el-form-item label="工作坊描述">
        <!-- <el-input class="wid50" v-model="formAdd.groupDescription"></el-input> -->
        <tinymce v-model="formAdd.groupDescription" :value='formAdd.groupDescription' :height="300" :width='400'></tinymce>
      </el-form-item>
      <!-- <el-form-item label="工作坊logo">
        <uploadImage :imgType = "'logo'" @getLogoImg='getLogoImg' :imageUrl='formAdd.groupLogo'></uploadImage>
      </el-form-item>
      <el-form-item label="封面图片">
        <uploadImage :imgType = "'cover'"  @getImg='getImg' :imageUrl='formAdd.groupImg'></uploadImage>
      </el-form-item> -->
      <el-form-item label="学段">
        <el-select v-model="formAdd.phaseCode" placeholder="请选择">
          <el-option
            v-for="item in phaseList"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="学科">
        <el-select v-model="formAdd.subjectCode" placeholder="请选择">
          <el-option
            v-for="item in subjectList"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="sure">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </el-form-item>
    </el-form>
    <!-- setLeader -->
    <setLeader v-if="setLeaderDialog" @leaderInfo='leaderInfo'></setLeader>
  </el-dialog>
</template>

<script>
import { insertGroup, updateGroup, fetchGroup } from '@/api/workshop.js'
import { studyPhase } from '@/utils/reallyMixin'
import { mapGetters } from 'vuex'
export default {
  data() {
    return {
      formAdd: {
        gradeCode: '',
        // groupAreaType: '',
        groupDescription: '',
        groupImg: '',
        groupIntroduction: '',
        groupLabel: '',
        groupLogo: '',
        groupName: '',
        groupTypeCode: [],
        segmentRelSubjects: [],
        projectId: '',
        subjectCode: '',
        phaseCode: '',
        shoolId: [],
        provinceCode: '',
        cityCode: '',
        countryCode: '',
        isSupportApply: '',
        status: ''
      },
      projectO: [],
      workShopTypeList: [], // 工作坊类型
      relationList: [], // 学段学科关联列表
      // phaseList: [], // 学段
      gradeListCur: [], // 年级
      subjectList: [], // 科目
      phaseList: [],
      schoolList: [], // 学校
      provinceList: [], // 省列表
      cityList: [], // 城市列表
      countryList: [], // 区列表
      setLeaderDialog: false,
      setleaderInfo: {} // 坊主信息
    }
  },
  computed: {
    ...mapGetters([
      'uuid',
      'gradeList'
    ])
  },
  mixins: [studyPhase],
  props: ['dialogVisibleAdd', 'itemContent', 'opeType'],
  watch: {
    'itemContent': function(val) {
      console.log(val === {})
      if (this.opeType === 'edit') {
        this.queryGroup()
      } else {
        this.formAdd.gradeCode = ''
        this.formAdd.groupDescription = ''
        this.formAdd.groupImg = ''
        this.formAdd.groupIntroduction = ''
        this.formAdd.groupLabel = ''
        this.formAdd.groupLogo = ''
        this.formAdd.groupName = ''
        this.formAdd.groupTypeCode = []
        this.formAdd.segmentRelSubjects = []
        this.formAdd.isSupportApply = '0'
        this.formAdd.status = '1'
      }
    }
  },
  components: {
    UploadSize: () => import('@/components/UploadSize.vue'),
    uploadImage: () => import('./uploadImage.vue'),
    tinymce: () => import('@/components/tinymce'),
    setLeader: () => import('./setLeader')
  },
  methods: {
    getImg(img) {
      console.log(img, '00000img')
      this.formAdd.groupImg = img
    },
    getLogoImg(img) {
      this.formAdd.groupLogo = img
    },
    cancel() {
      this.$emit('cancel')
    },
    sure() {
      this.addGroup()
    },
    addGroup() {
      if (!this.formAdd.groupName) {
        this.$message({ message: '请填写工作坊名称', type: 'warning' })
        return
      }
      const data = {
        // adminUserId: this.setleaderInfo.id || '',
        // gradeCode: this.formAdd.gradeCode, // 年级
        groupDescription: this.formAdd.groupDescription, // 描述
        // groupImg: this.formAdd.groupImg, // 封面
        groupIntroduction: this.formAdd.groupIntroduction, // 简介
        // groupLabel: this.formAdd.groupLabel, // 标签
        // groupLogo: this.formAdd.groupLogo, // logo
        groupName: this.formAdd.groupName, // 工作坊名称
        segSubs: [
          {
            segmentCode: this.formAdd.phaseCode,
            subjectCode: this.formAdd.subjectCode
          }
        ]
        // groupTypeCode: this.formAdd.groupTypeCode, // 工作坊类型编码
        // mapTypes: {},
        // segsubCodes: this.formAdd.segmentRelSubjects, // 学段学科关联
        // status: this.formAdd.status * 1, // 状态
        // creatorId: this.uuid
        // projectId: this.formAdd.projectId
      }

      // if (this.environment) {
      //   data.adminUserId = this.setleaderInfo.id || ''
      //   data.creatorId = this.uuid
      //   data.projectId = this.formAdd.projectId
      // }
      data.adminUserId = this.setleaderInfo.id || this.formAdd.adminUserId || ''
      data.creatorId = this.uuid
      // data.projectId = this.formAdd.projectId
      let opeFn = null
      console.log(this.opeType, 'lk')
      if (this.opeType === 'add') {
        opeFn = insertGroup
      }
      if (this.opeType === 'edit') {
        opeFn = updateGroup
        data.id = this.itemContent.id
      }
      opeFn(data).then(res => {
        console.log(res)
        if (res.data.code === 200) {
          this.$emit('save')
        } else {
          this.$message({ message: res.data.msg, type: 'error' })
        }
      })
    },
    queryGroup() {
      const data = {
        id: this.itemContent.id
      }
      fetchGroup(data).then(res => {
        console.log(res)
        if (res.data.code === 200) {
          // this.formAdd.adminUserName = res.data.result.adminUserName
          // this.formAdd.gradeCode = res.data.result.gradeCode
          // this.formAdd.groupDescription = res.data.result.groupDescription ? res.data.result.groupDescription : ''
          // this.formAdd.groupImg = res.data.result.groupImg
          // this.formAdd.groupIntroduction = res.data.result.groupIntroduction
          // this.formAdd.groupLabel = res.data.result.groupLabel
          // this.formAdd.groupLogo = res.data.result.groupLogo
          // this.formAdd.groupName = res.data.result.groupName
          this.formAdd = res.data.result
          this.formAdd.subjectCode = res.data.result.groupSegSubs.length ? res.data.result.groupSegSubs[0].subjectCode : ''
          this.formAdd.phaseCode = res.data.result.groupSegSubs.length ? res.data.result.groupSegSubs[0].segmentCode : ''
        }
      })
    },
    chooseLeader() {
      this.setLeaderDialog = true
    },
    leaderInfo(val) {
      this.setLeaderDialog = false
      if (val) {
        this.setleaderInfo = val
      }
    }
  },
  mounted() {
    if (this.opeType === 'edit') {
      this.queryGroup()
    } else {
      this.formAdd.gradeCode = ''
      this.formAdd.groupDescription = ''
      this.formAdd.groupImg = ''
      this.formAdd.groupIntroduction = ''
      this.formAdd.groupLabel = ''
      this.formAdd.groupLogo = ''
      this.formAdd.groupName = ''
      this.formAdd.groupTypeCode = []
      this.formAdd.segmentRelSubjects = []
      this.formAdd.isSupportApply = '0'
      this.formAdd.status = '1'
    }
    this.subject().then(res => {
      console.log(res)
      this.subjectList = res
    })
    this.phase().then(res => {
      this.phaseList = res
    })
  }
}
</script>

<style scoped lang='scss'>
.wid50{
  width: 50%;
}
.wid60{
  width: 60%;
}
</style>
