<template>
    <div>WorkshopEdit</div>
</template>

<script>
export default {
  name: 'WorkshopEdit',
  data() {
    return {}
  },
  computed: {},
  mounted() {
  },
  methods: {}
}
</script>

<style scoped>

</style>
