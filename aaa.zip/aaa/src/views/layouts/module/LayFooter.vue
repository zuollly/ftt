<template>
  <el-footer class="footerWrapperCon mt-3">
    <!-- <div class="text-center">
      {{this.$store.getters.appConfig.app_powerby}}
    </div> -->
    <div class="footerWrapper text-center" style="line-height: 60px">
      <!-- {{sysBasicConfig.cfg_powerby}} -->
      <div class="top">主办单位：新疆生产建设兵团教育局</div>
      <div class="top">运行维护：兵团中小学电化教育馆（兵团教育技术装备管理中心） 新ICP备14002153号-3</div>
      <div class="bottom">
        <div class="bottomCon">
          <div class="div">
            <img src="https://ss0.bdstatic.com/94oJfD_bAAcT8t7mm9GUKT-xh_/timg?image&quality=100&size=b4000_4000&sec=1562143976&di=66d04a32136cdb1add9a7bfa6f4144f9&src=http://photo.16pic.com/00/26/39/16pic_2639672_b.jpg" alt="">
          </div>
          <p>新公网安备65010202001001号</p>
        </div>
      </div>
    </div>
  </el-footer>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
  computed: {
    ...mapGetters([
      'appConfig',
      'environment'
    ])
  }
  // methods: {
  //   getFooterStyle: function() {
  //     if (this.themeConfig.fixSiderbar && this.themeConfig.layout !== 'topmenu' && !this.isMobile) {
  //       return {
  //         left: this.openSidebar ? '72px' : '240px'
  //       }
  //     }
  //     return null
  //   }
  // }
}
</script>
<style lang="scss" rel="stylesheet/scss">
.footerWrapperCon{
  display: table;
  margin: 0 auto;
  width: 80%;
}
.footerWrapper{
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  display: table;
  margin: 0 auto;
  width: 100%;
  .top{
    line-height: 25px;
    width: 50%;
    margin: 0 auto;
  }
  .bottom{
    line-height: 25px;
    .bottomCon{
      display: flex;
      justify-content: space-around;
      align-items: center;
      align-content: center;
      width: 30%;
      margin: 0 auto;
      .div{
        width: 35%;
        text-align: right;
        margin-bottom: 15px;
      }
      img{
        width: 20px;
        height: 20px;
        vertical-align: middle;
      }
      p{
        width: 63%;
        text-align: left;
        padding: 0;
        margin: 0;
      }
    }
  }
}
</style>
