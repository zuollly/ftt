<template>
  <el-aside class="lay-sider" :class="siderClassName()" :style="getAsideStyle()">
    <!--是否固定在 fixed-->
    <!--是否高亮-->
    <!--左侧边栏是否存在-->
    <!--是否是手机-->
    <div class="lay-sider-logo">
      <router-link to="/"><img :src="logo.logo"/> <h1>{{ logo.name }}</h1></router-link>
    </div>

    <template v-if="themeConfig.fixSiderbar">
      <el-scrollbar wrap-class="scrollbar-wrapper" :style="getScrollbarStyle()">
        <nav-menu mode="vertical" :onCollapse="onCollapse" :menuData="menuData"></nav-menu>
      </el-scrollbar>
    </template>
    <template v-else>
      <nav-menu mode="vertical" :onCollapse="onCollapse" :menuColor="themeConfig.primaryColor" :menuData="menuData"></nav-menu>
    </template>
  </el-aside>
</template>
<script>
import NavMenu from '../components/menu/NavMenu'
export default {
  components: {
    NavMenu
  },
  props: {
    logo: {
      type: Object
    },
    menuData: {
      type: Array
    },
    onCollapse: {
      type: Boolean,
      default: true
    },
    themeConfig: {
      type: Object
    },
    isMobile: {
      type: Boolean
    }
  },
  mounted() {
    console.log('LayAside' + typeof this.onCollapse)
    console.log(typeof this.themeConfig.primaryColor)
  },
  methods: {
    siderClassName: function() {
      return [
        'lay-sider-' + this.themeConfig.navTheme,
        this.themeConfig.fixSiderbar ? 'lay-sider-fixed' : null
      ]
    },
    getAsideStyle: function() {
      return { width: this.onCollapse ? '72px' : '240px' }
    },
    getScrollbarStyle: function() {
      return { height: this.themeConfig.fixSiderbar ? 'calc(100% - 60px)' : null }
    }
  }
}
</script>
<style lang="scss" rel="stylesheet/scss">
  /*.el-scrollbar__wrap {*/
  /*overflow-x: hidden;*/
  /*}*/

  .lay-sider{
    padding-top: .1px;
    margin-top: -.1px;
    transition: all .2s;
    min-width: 0;
    min-height: 100vh;
    position: relative;
    z-index: 3;
    .lay-sider-logo{
      height: 60px;
      position: relative;
      line-height: 60px;
      padding-left: 20px;
      transition: all .3s;
      overflow: hidden;
      z-index: 5;
      a:hover{
        text-decoration: none;
      }
      img{
        display: inline-block;
        vertical-align: middle;
        height: 32px;
      }
      h1{
        display: inline-block;
        vertical-align: middle;
        font-size: 20px;
        margin: 0 0 0 12px;
        font-weight: 600;
      }
    }
    .el-menu {
      border-right: none;
      .el-submenu{
        font-size: 14px;
        >.el-submenu__title .svg-icon{
          width: 1em;
          height: 1em;
          vertical-align: middle;
          margin-right: 8px;
          transition: width .3s, height .3s;
        }
      }
      > .el-menu-item{
        .svg-icon{
          width: 1em;
          height: 1em;
          vertical-align: middle;
          margin-right:8px;
          transition: width .3s, height .3s;
        }
      }
    }
    .el-menu--collapse{
      width: 72px;
      >.el-menu-item [class^=el-icon-],
      >.el-submenu>.el-submenu__title [class^=el-icon-]{
        margin-left: 4px;
        font-size: 18px;
      }
    }
    .el-menu--collapse{
      >.el-menu-item .svg-icon,
      >.el-submenu>.el-submenu__title .svg-icon{
        width: 1.15em;
        height: 1.15em;
        margin-left: 6px;
        margin-right: 0px;
        transition: width .3s, height .3s;
      }
    }
  }
  .lay-sider-dark{
    //.el-submenu__title,
    //.el-menu-item{
    //  height: 40px;
    //  line-height: 40px;
    //}
  }
  .lay-sider-light{}
  .lay-sider-fixed{
    position: fixed;
    top: 0;
    left: 0;
    bottom: 0;
    overflow: hidden;
  }
</style>
