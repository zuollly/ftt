<template>
  <div>
    <div class="lay-page-header">
      <div :class="getContentClassName()">
        <div v-if="themeConfig.layout === 'topmenu'" class="d-flex justify-content-start">
          <div class="align-self-center"><svg-icon icon-class="dashboard" /></div>
          <div><lay-breadcrumb></lay-breadcrumb></div>
        </div>
        <div class="lay-page-header-main" :style="getContentStyle()">
          <div class="lay-page-header-title">
            <h1>{{$route.meta.title}}</h1>
          </div>
          <div class="lay-page-header-desc">
            <!-- 表单页用于向用户收集或验证信息，基础表单常见于数据项较少的表单场景。 -->
          </div>
        </div>
      </div>
    </div>
    <el-main class="lay-main">
      <div :class="getContentClassName()">
    <el-card shadow="never" :body-style="{ padding: '10px' }">
    <router-view></router-view>
    </el-card>
      </div>
    </el-main>
  </div>
</template>
<script>
import LayBreadcrumb from '@/components/LayBreadcrumb'
export default {
  name: 'LayMain',
  components: { LayBreadcrumb },
  props: {
    themeConfig: {
      type: Object
    }
  },
  methods: {
    getContentStyle: function() {
      return {
        padding: this.themeConfig.layout !== 'topmenu' ? '16px 20px 0' : '10px 0 0 0'
      }
    },
    getContentClassName: function() {
      return [
        this.themeConfig.contentWidth === 'Fluid' && this.themeConfig.layout === 'topmenu' ? 'container' : 'container-fluid'
      ]
    }
  }
}
</script>
<style>
  .el-main.lay-main{padding: 20px 10px}
</style>
<style lang="scss" rel="stylesheet/scss">
  $pagename: 'lay-page-header';
  .#{$pagename}{
    background-color: white;
    border-bottom: 1px solid #e8e8e8;
    .#{$pagename}-main{
      padding: 24px 24px 0;
    }
    .#{$pagename}-title{
      h1{
        color: rgba(0, 0, 0, 0.85);
        margin-top: 0px;
        font-weight: 400;
        font-size: 18px;
        margin-bottom: 15px;
      }
    }
    .#{$pagename}-desc{
      flex: auto;
      margin-bottom: 15px;
    }
  }
</style>
