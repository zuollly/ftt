<template>
  <el-header class="lay-header" :class="getLayHeaderClassName()" :style="getLayHeaderStyle()">
    <!--是否固定在 fixed, 如果是在滚动时是否隐藏-->
    <!--是否高亮-->
    <!--左侧边栏是否存在-->
    <!--是否是手机-->
    <div :class="getLayContainerClassName()">
      <div class="lay-header-bar">
        <div class="lay-header-logo" v-if="isTop">
          <router-link to="/"><img :src="logo.logo" style="width: 30px"/>
            <h1 v-if="!isMobile">{{ logo.name }}</h1></router-link>
        </div>
        <div class="lay-header-handle" v-if="!isTop">
          <div class="d-flex justify-content-start">
            <handle-aside :toggleClick="handleSidebar" :isActive="onCollapse" class="align-self-center"></handle-aside>
            <lay-breadcrumb class="ml-3"></lay-breadcrumb>
          </div>
        </div>
        <div class="lay-header-nav" v-if="isTop" :style="setHeaderNavStyle()">
          <nav-menu mode="horizontal" :menuData="menuData"></nav-menu>
        </div>
        <global-header/>
      </div>
    </div>
  </el-header>
</template>
<script>
import NavMenu from '../components/menu/NavMenu'
import HandleAside from '../components/handleAside'
import GlobalHeader from '../components/globalHeader'
import LayBreadcrumb from '@/components/LayBreadcrumb'
export default {
  components: {
    NavMenu, HandleAside, GlobalHeader, LayBreadcrumb
  },
  props: {
    logo: {
      type: Object
    },
    menuData: {
      type: Array
    },
    onCollapse: {
      type: Boolean,
      default: false
    },
    themeConfig: {
      type: Object
    },
    handleSidebar: {
      type: Function
    },
    isMobile: {},
    isTop: {}
  },
  mounted() {

  },
  methods: {
    getLayHeaderClassName: function() {
      return [
        this.themeConfig.layout === 'topmenu' && this.themeConfig.navTheme === 'dark' ? 'lay-header-dark' : 'lay-header-light',
        this.themeConfig.fixedHeader ? 'lay-header-top-fixed' : null
      ]
    },
    getLayHeaderStyle: function() {
      return {
        left: this.themeConfig.layout === 'topmenu' ? '0' : this.themeConfig.fixedHeader ? this.onCollapse ? '72px' : '240px' : null,
        marginLeft: this.themeConfig.layout === 'topmenu' ? '0' : null
      }
    },
    setHeaderNavStyle: function() {
      return {
        minWidth: this.themeConfig.contentWidth === 'Fluid' && this.themeConfig.layout === 'topmenu' ? '690px' : null
      }
    },
    getLayContainerClassName: function() {
      return [
        this.themeConfig.contentWidth === 'Fluid' && this.themeConfig.layout === 'topmenu' ? 'container' : 'container-fluid'
      ]
    }
  }
}
</script>
