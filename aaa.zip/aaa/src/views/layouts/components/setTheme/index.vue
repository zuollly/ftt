<template>
  <lay-drawer
    :visible="collapse"
    width="300"
    :onClose="togglerContent"
    title=""
    placement="right"
    :handler="setIcon"
    :onHandleClick="togglerContent">
    <div class="lay-theme">
      <h5 class="lay-theme-title">整体风格设置</h5>
      <div class="lay-theme-body">
        <div class="d-flex flex-row">
          <div class="nav-item mr-3" @click="setNavTheme(item.tag)" v-for="item in navTheme" :key="item.tag">
            <el-tooltip class="item" effect="dark" :content="item.name" placement="top">
              <img :src="item.img"/>
            </el-tooltip>
            <div class="selectIcon" v-if="item.tag == themeConfig.navTheme"><i class="el-icon el-icon-check text-primary"></i></div>
          </div>
        </div>
      </div>
      <h5 class="lay-theme-title">主题色</h5>
      <div class="lay-theme-body">
        <div class="d-flex flex-row">
          <div class="color-item rounded" v-for="item in primaryColor" :index="item" :key="item" @click="setColor(item)" v-bind:style="{ backgroundColor: '#'+ item }">
            <i class="el-icon el-icon-check text-white" v-if="item == themeConfig.primaryColor"></i>
          </div>
        </div>
      </div>
      <h5  class="lay-theme-title">导航模式</h5>
      <div class="lay-theme-body">
        <div class="d-flex flex-row">
          <div class="layout-item mr-3" @click="setLayout(item.tag)" v-for="item in layout" :key="item.tag">
            <el-tooltip class="item" effect="dark" :content="item.name" placement="top">
              <img :src="item.img"/>
            </el-tooltip>
            <div class="selectIcon" v-if="item.tag == themeConfig.layout"><i class="el-icon el-icon-check text-primary"></i></div>
          </div>
        </div>
      </div>
      <div class="lay-theme-list-group">
        <div class="lay-theme-list-item">
          <div class="d-flex">
            <div class="mr-auto" :class="getContentClass.className">内容区域宽度</div>
            <div>
              <el-select v-model="contentVal" size="mini" style="width: 80px" :disabled="getContentClass.disabled" @change="setContent" placeholder="请选择">
                <el-option
                  v-for="item in contentWidth"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </div>
          </div>
        </div>
        <div class="lay-theme-list-item">
          <div class="d-flex">
            <div class="mr-auto">固定 Header</div>
            <div><el-switch v-model="themeConfig.fixedHeader"></el-switch></div>
          </div>
        </div>
        <div class="lay-theme-list-item">
          <div class="d-flex" :class="getAutoHideHeaderClass.className">
            <div class="mr-auto">下滑时隐藏 Header</div>
            <div><el-switch v-model="themeConfig.autoHideHeader" :disabled="getAutoHideHeaderClass.disabled"></el-switch></div>
          </div>
        </div>
        <div class="lay-theme-list-item">
          <div class="d-flex">
            <div class="mr-auto" :class="getFixSiderbarClass.className">固定侧边菜单</div>
            <div><el-switch v-model="themeConfig.fixSiderbar" :disabled="getFixSiderbarClass.disabled"></el-switch></div>
          </div>
        </div>
      </div>
    </div>
  </lay-drawer>
</template>
<script>
import LayDrawer from '@/views/layouts/components/layDrawer/LayDrawer'
export default {
  name: 'SetTheme',
  components: { LayDrawer },
  data() {
    return {
      collapse: false,
      navTheme: [
        { tag: 'dark', name: '暗色菜单风格', img: 'https://gw.alipayobjects.com/zos/rmsportal/LCkqqYNmvBEbokSDscrm.svg' },
        { tag: 'light', name: '亮色菜单风格', img: 'https://gw.alipayobjects.com/zos/rmsportal/jpRkZQMyYRryryPNtyIC.svg' }
      ], // theme for nav menu
      primaryColor: ['f5222d', 'fa541c', 'faad14', '13c2c2', '52c41a', '1890ff', '2f54eb', '722ed1'], // primary color of ant design
      layout: [
        { tag: 'sidemenu', name: '侧边菜单布局', img: 'https://gw.alipayobjects.com/zos/rmsportal/JopDzEhOqwOjeNTXkoje.svg' },
        { tag: 'topmenu', name: '顶部菜单布局', img: 'https://gw.alipayobjects.com/zos/rmsportal/KDNDBbriJhLwuqMoxcAr.svg' }
      ],
      contentVal: ''
    }
  },
  props: {
    themeConfig: {
      type: Object,
      default: () => {
        return {}
      }
    },
    containerName: {
      type: String
    }
  },
  computed: {
    setIcon: function() {
      return this.collapse ? '<i class="el-icon-close text-white" style="font-size: 20px"></i>' : '<i class="el-icon-setting text-white" style="font-size: 20px"></i>'
    },
    getContentClass: function() {
      var classVal = {
        className: [],
        disabled: false
      }
      if (this.themeConfig.layout !== 'topmenu') {
        classVal.className = ['text-muted']
        classVal.disabled = true
      }
      return classVal
    },
    getAutoHideHeaderClass: function() {
      var classVal = {
        className: ['text-muted'],
        disabled: true
      }
      if (this.themeConfig.layout === 'topmenu' && this.themeConfig.fixedHeader) {
        classVal.className = ['text-muted']
        classVal.disabled = false
      }
      return classVal
    },
    getFixSiderbarClass: function() {
      var classVal = {
        className: [],
        disabled: false
      }
      if (this.themeConfig.layout === 'topmenu') {
        classVal.className = ['text-muted']
        classVal.disabled = true
      }
      return classVal
    },
    contentWidth: function() {
      var content = []
      if (this.themeConfig.layout === 'topmenu') {
        content.push({ value: 'Fixed', label: '流式' })
        content.push({ value: 'Fluid', label: '定宽' })
      } else {
        content.push({ value: 'Fixed', label: '流式' })
      }
      return content
    }
  },
  mounted() {
    this.setContentVal()
  },
  methods: {
    setNavTheme: function(item) {
      if (this.themeConfig.navTheme !== item) {
        this.themeConfig.navTheme = item
        this.$store.dispatch('setThemeParam', this.themeConfig)
      }
    },
    setColor: function(item) {
      if (this.themeConfig.primaryColor !== item) {
        this.themeConfig.primaryColor = item
        this.$store.dispatch('setThemeParam', this.themeConfig)
      }
    },
    setLayout: function(item) {
      if (this.themeConfig.layout !== item) {
        this.themeConfig.layout = item
        this.setContentVal()
        this.$store.dispatch('setThemeParam', this.themeConfig)
      }
    },
    setContent: function(item) {
      if (this.themeConfig.layout !== item) {
        this.themeConfig.contentWidth = item
        this.$store.dispatch('setThemeParam', this.themeConfig)
      }
    },
    setContentVal: function() {
      this.contentVal = this.themeConfig.layout === 'topmenu' ? this.themeConfig.contentWidth : 'Fixed'
    },
    togglerContent: function() {
      if (this.collapse) {
        this.collapse = false
        this.$store.dispatch('setThemeParam', this.themeConfig)
      } else {
        this.collapse = true
      }
    }
  }
}
</script>
<style lang="scss" rel="stylesheet/scss" scoped="scoped">
  $name: 'lay-theme';
  .#{$name}{
    .#{$name}-header{
    }
    .#{$name}-title{
      font-size: 14px;
      font-weight: 400;
      margin: 0;
      padding: 5px 0px;
    }
    .#{$name}-body{
      padding: 10px 0px;
    }

    .#{$name}-list-group{
      display: flex;
      flex-direction: column;
      padding-left: 0; // reset padding because ul and ol
      margin-bottom: 0;
      color: rgba(0,0,0,.65);
    }
    .#{$name}-list-item{
      position: relative;
      display: block;
      padding: .75rem 0rem;
    }
    .nav-item{
      position: relative;
      cursor: pointer;
      .selectIcon{
        position: absolute;
        text-align: center;
        top: 12px;
        left: 24px;
      }
    }
    .color-item{
      width: 20px;
      height: 20px;
      text-align: center;
      cursor: pointer;
      margin-right: 8px;
    }
    .layout-item{
      position: relative;
      cursor: pointer;
      .selectIcon{
        position: absolute;
        text-align: center;
        top: 12px;
        left: 24px;
      }
    }
  }
</style>
