<template>
    <el-menu
      :mode="mode"
      :default-active="$route.matched[2].parent.name"
      @select="handleSelect"
      :collapse="onCollapse"
    >
      <menu-item :menuData="dataTree"></menu-item>
    </el-menu>
</template>
<script>
import MenuItem from './MenuItem'
export default {
  name: 'NavMenu',
  components: {
    MenuItem
  },
  data() {
    return {
      isCollapse: true,
      dataTree: []
    }
  },
  props: {
    mode: {
      type: String,
      default: 'horizontal'
    },
    menuData: {
      type: Array
    },
    onCollapse: {
      type: Boolean,
      default: false
    }
  },
  mounted() {
    // console.log('this.$router.matcher', this.$route)
    var tree = []
    for (let i = 0; i < this.menuData.length; i++) {
      console.log('this.menuData[i].name', this.menuData[i].name)
      if (this.menuData[i].name === 'school') {
        tree = this.menuData[i].children
      }
    }
    if (this.mode === 'horizontal') {
      this.dataTree = this.getTopMenuItem(this.getSideMenuItem(this.getNavMenuItems(tree)))
    } else {
      this.dataTree = this.getSideMenuItem(this.getNavMenuItems(tree))
    }
    console.log(this.dataTree)
  },
  methods: {
    getNavMenuItems: function(list) {
      var _this = this
      const accessedList = list.filter(item => {
        if (!item.hidden) {
          if (item.children && item.children.length) {
            item.children = _this.getNavMenuItems(item.children)
          }
          return true
        }
        return false
      })
      return accessedList
    },
    getSideMenuItem: function(list) {
      var _this = this
      const accessedList = list.filter(item => {
        if (!item.hidden) {
          if (item.children) {
            if (item.children.length === 0) { delete item.children } else {
              item.children = _this.getSideMenuItem(item.children)
            }
          }
          return true
        }
        return false
      })
      return accessedList
    },
    getTopMenuItem: function(list) {
      var newList = []
      var sum = 6
      list.forEach(function(item, index) {
        if (index < sum) {
          newList.push(item)
        } else {
          if (newList.length <= sum) {
            newList.push(
              { path: '···', name: '···', meta: { title: '···' }, children: [] })
          }
          newList[sum].children.push(item)
        }
      })
      return newList
    },
    handleSelect: function(key) {
      var name = key
      var id = this.$route.params.id
      this.$router.push({
        name: name, params: { id: id }
      })
    }
  }
}
</script>
