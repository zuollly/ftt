<template>
  <el-dropdown>
    <span class="el-dropdown-link"><svg-icon icon-class="global" /></span>
    <el-dropdown-menu slot="dropdown">
      <el-dropdown-item>中文</el-dropdown-item>
      <el-dropdown-item>English</el-dropdown-item>
      <el-dropdown-item>Español</el-dropdown-item>
    </el-dropdown-menu>
  </el-dropdown>
</template>
