<template>
  <el-tooltip class="item" effect="dark" content="帮助文档" placement="bottom">
    <a href="/help" class="header-action"><svg-icon icon-class="question-circle" /></a>
  </el-tooltip>
</template>
