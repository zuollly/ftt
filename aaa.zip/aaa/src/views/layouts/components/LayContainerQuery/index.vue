<template>
  <div>
    <slot></slot>
  </div>
</template>

<script>
import { getMobile } from '@/utils/browser/index'
import { addClass } from '@/utils/jquery/setClass'
import { mapGetters } from 'vuex'
export default {
  name: 'LayContainerQuery',
  data() {
    return {
      containerName: '',
      screenWidth: document.documentElement.clientWidth,
      screenHeight: document.documentElement.clientHeight,
      query: {
        'screen-xs': {
          maxWidth: 575
        },
        'screen-sm': {
          minWidth: 576,
          maxWidth: 767
        },
        'screen-md': {
          minWidth: 768,
          maxWidth: 991
        },
        'screen-lg': {
          minWidth: 992,
          maxWidth: 1199
        },
        'screen-xl': {
          minWidth: 1200,
          maxWidth: 1599
        },
        'screen-xxl': {
          minWidth: 1600
        }
      }
    }
  },
  computed: {
    ...mapGetters([
      'themeConfig'
    ])
  },
  watch: {
    themeConfig: function(val) {
      var _this = this
      _this.setBodyClassName()
    },
    screenHeight: function(val) {
      var _this = this
      if (!this.timer) {
        _this.screenHeight = val
        _this.timer = true
        setTimeout(function() {
          _this.timer = false
        }, 400)
      }
    },
    screenWidth: function(val) {
      var _this = this
      if (!this.timer) {
        _this.screenHeight = val
        this.containerQuery()
        _this.timer = true
        setTimeout(function() {
          _this.timer = false
        }, 400)
      }
    }
  },
  mounted() {
    const _this = this
    _this.containerQuery()
    // window.addEventListener("resize", function() {
    window.onresize = () => {
      return (() => {
        window.screenWidth = document.documentElement.clientWidth
        window.screenHeight = document.documentElement.clientHeight
        _this.screenWidth = window.screenWidth
        _this.screenHeight = window.screenHeight
        this.containerQuery()
      })()
    }
  },
  methods: {
    containerQuery: function() {
      var containerNames = ''
      if (this.screenWidth <= this.query['screen-xs'].maxWidth) { containerNames = 'screen-xs' }
      if (this.screenWidth >= this.query['screen-sm'].minWidth && this.screenWidth <= this.query['screen-sm'].maxWidth) { containerNames = 'screen-sm' }
      if (this.screenWidth >= this.query['screen-md'].minWidth && this.screenWidth <= this.query['screen-md'].maxWidth) { containerNames = 'screen-md' }
      if (this.screenWidth >= this.query['screen-lg'].minWidth && this.screenWidth <= this.query['screen-lg'].maxWidth) { containerNames = 'screen-lg' }
      if (this.screenWidth >= this.query['screen-xl'].minWidth && this.screenWidth <= this.query['screen-xl'].maxWidth) { containerNames = 'screen-xl' }
      if (this.screenWidth >= this.query['screen-xxl'].minWidth) { containerNames = 'screen-xxl' }
      this.$store.dispatch('SetContainerName', containerNames)
      this.$store.dispatch('SetIsMobile', getMobile())
      this.containerName = containerNames
      this.setBodyClassName()
    },
    setBodyClassName: function() {
      var bodyEle = document.getElementsByTagName('body')[0]
      bodyEle.setAttribute('class', '')
      addClass(bodyEle, 'custom-' + this.themeConfig.primaryColor)
      addClass(bodyEle, 'lay-' + this.themeConfig.navTheme)
      addClass(bodyEle, this.containerName)
    }
  }
}
</script>
