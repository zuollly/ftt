<template>
  <el-dropdown placement="top">
    <span class="el-dropdown-link"><span class="user-brand"><img :src="userAvatar" class="rounded-circle" style="width: 24px"/><span>{{userName}}</span></span></span>
    <el-dropdown-menu style="min-width: 160px;" class="lay-user-menu" slot="dropdown">
      <!-- <el-dropdown-item v-if="!environment" @click.native="gotoMember('settings')"><svg-icon icon-class="setting" /> 帐号设置</el-dropdown-item>
      <el-dropdown-item v-if="!environment" @click.native="gotoMember('center')"><svg-icon icon-class="user" /> 个人中心</el-dropdown-item>
      <el-dropdown-item divided @click.native="gotoMember('homePage')"><svg-icon icon-class="menhu" /> 门户首页</el-dropdown-item>
      <el-dropdown-item v-if="!environment" divided  @click.native="logout"><svg-icon icon-class="logout" />退出登录</el-dropdown-item> -->
    </el-dropdown-menu>
  </el-dropdown>
</template>
<script>
import { mapGetters } from 'vuex'
import { getToken } from '@/utils/storage/cookies'
export default {
  name: 'CurrentUser',
  computed: {
    ...mapGetters([
      'userName',
      'userAvatar', 'appConfig', 'environment'
    ])
  },
  methods: {
    gotoMember(name) {
      if (name === 'settings') { window.open(this.appConfig.app_settings_path) }
      if (name === 'center') { window.open(this.appConfig.app_center_path) }
      // if (name === 'editpassword') { window.location.href = this.appConfig.app_editpassword_path }
      if (name === 'homePage' && this.environment) {
        window.open(`${this.appConfig.app_homePage}?token=` + getToken())
      } else {
        window.open(this.appConfig.app_homePage)
      }
    },
    logout() {
      this.$store.dispatch('FedLogOut').then(() => {
        location.reload()// In order to re-instantiate the vue-router object to avoid bugs
      })
    }
  }
}
</script>
