<template>
  <div class="lay-header-global">
    <!-- <span class="header-action"><search-icon/></span> -->
    <!-- <help-icon/> -->
    <!-- <notice-icon/> -->
    <span class="header-action"><current-user/></span>
    <!-- <span class="header-action"><select-lang/></span> -->
  </div>
</template>
<script>
import SearchIcon from '@/views/layouts/components/searchIcon'
import HelpIcon from '@/views/layouts/components/helpIcon'
import NoticeIcon from '@/views/layouts/components/noticeIcon'
import CurrentUser from '@/views/layouts/components/currentUser'
import SelectLang from '@/views/layouts/components/selectLang'
export default {
  components: {
    SearchIcon, HelpIcon, NoticeIcon, CurrentUser, SelectLang
  }
}
</script>
<style lang="scss" rel="stylesheet/scss">
  .lay-header-global {
    margin-left: auto !important;
    overflow: hidden;
    height: 60px;
    line-height: 60px;
    .svg-icon{
      width: 1em;
      height: 1em;
    }
    .header-action {
      cursor: pointer;
      padding: 0 12px;
      display: inline-block;
      transition: all .3s;
      height: 100%;
      .el-dropdown{
        line-height: 59px;
      }
    }
    .user-brand {
      display: inline-block;
      line-height: 1;
      white-space: nowrap;
      text-overflow: ellipsis;
      img {
        display: inline-block !important;
        vertical-align: middle;
        margin-right: 8px;
      }
    }
  }
</style>
