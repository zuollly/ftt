<template>
  <lay-container-query>
    <el-container class="lay-body">
      <template v-if="!isTop">
        <lay-aside
          :logo="logo"
          :menuData="Router"
          :themeConfig="themeConfig"
          :onCollapse="openSidebar"
          :isMobile="isMobile"
        ></lay-aside>
      </template>
      <el-container
        class="is-vertical"
        :style="getLayoutStyle()"
      >
        <lay-header
          :menuData="Router"
          :logo="logo"
          :themeConfig="themeConfig"
          :isMobile="isMobile"
          :onCollapse="openSidebar"
          :handleSidebar="handleSidebar"
          :isTop="isTop"
        ></lay-header>
        <lay-main
          :style="getContentStyle()"
          :themeConfig="themeConfig"
        ></lay-main>
        <!-- <div class="footerWrapper" :style="getFooterStyle()">
        </div> -->
        <lay-footer/>
      </el-container>

      <set-theme :themeConfig="themeConfig" :containerName="containerName"></set-theme>
    </el-container>
  </lay-container-query>
</template>
<script>
import LayAside from './module/LayAside'
import LayHeader from './module/LayHeader'
import LayMain from './module/LayMain'
import LayFooter from './module/LayFooter'
import SetTheme from './components/setTheme'
import LayContainerQuery from './components/LayContainerQuery'
import { mapGetters } from 'vuex'
import logo from '@/assets/logo.svg'
import { constantRouterMap } from '@/router'
export default {
  components: { LayContainerQuery, LayAside, LayHeader, LayMain, LayFooter, SetTheme },
  data() {
    return {
      logo: {
        logo: logo,
        name: '教师研修培训服务'
      },
      Router: constantRouterMap,
      handleMenuCollapse: false
    }
  },
  computed: {
    ...mapGetters([
      'openSidebar', 'themeConfig', 'isMobile', 'containerName'
    ]),
    isTop: function() {
      return this.themeConfig.layout === 'topmenu'
    },
    navTheme: function() {
      return this.themeConfig.navTheme
    }
  },
  created() {
    this.logo.name = '名师工作室'
  },
  mounted() {
    console.log(this.themeConfig, '-')
    console.log('openSidebar: ' + typeof this.openSidebar)
    // console.log('isTop:' + this.isTop)
    // this.handleSidebar()
  },
  methods: {
    screen: function() {

    },
    getLayoutStyle: function() {
      if (this.themeConfig.fixSiderbar && this.themeConfig.layout !== 'topmenu' && !this.isMobile) {
        return {
          paddingLeft: this.openSidebar ? '72px' : '240px',
          minHeight: '100vh'
        }
      }
      return null
    },
    getFooterStyle: function() {
      if (this.themeConfig.fixSiderbar && this.themeConfig.layout !== 'topmenu' && !this.isMobile) {
        return {
          left: this.openSidebar ? '72px' : '240px',
          position: 'absolute',
          bottom: '10px',
          width: this.openSidebar ? '100%' - '72px' : '100%' - '240px',
          height: '60px'
        }
      }
      return null
    },
    getContentStyle: function() {
      return {
        paddingTop: this.themeConfig.fixedHeader ? '60px' : 0,
        minHeight: 'calc(100vh - 140px)'
      }
    },
    getContentClassName: function() {
      return [
        this.themeConfig.contentWidth === 'Fluid' && this.themeConfig.layout === 'topmenu' ? 'container' : null
      ]
    },
    handleSidebar: function() {
      this.$store.dispatch('toggleSideBar')
    }
  }
}
</script>
<style lang='scss'>
  .lay-body{
    background: #f0f2f5;
    min-height: 0;
    .is-vertical{
      position: relative;
    }
  }
</style>
