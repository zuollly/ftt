<template>
  <div>500</div>
</template>

<script>
export default {
  data() {
    return {}
  },
  computed: {},
  mounted() {
  },
  methods: {}
}
</script>

<style scoped>

</style>
