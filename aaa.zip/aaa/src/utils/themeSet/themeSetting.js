// navTheme: 'dark', // 整体风格设置（导航背景）
// primaryColor: '#1890FF', // 主题颜色
// layout: 'sidemenu ｜ topmenu', // 导航模式
// contentWidth: 'Fluid', // 内容区域宽度 如果当前导航模式为sidemenu哪么只能是流式，如果是topmenu哪可以选择定宽或流式 layout of content: Fluid or Fixed, only works when layout is topmenu
// fixedHeader: false, // sticky header 固定头部
// autoHideHeader: false, // auto hide header 下滑时隐藏顶部
// fixSiderbar: false, // sticky siderbar 让sidemenu固定高度出现滚动条
module.exports = {
  navTheme: 'dark', // theme for nav menu
  primaryColor: '1890ff', // primary color of ant design
  layout: 'sidemenu', // nav menu position: sidemenu or topmenu
  contentWidth: 'Fluid', // layout of content: Fluid or Fixed, only works when layout is topmenu
  fixedHeader: true, // sticky header
  autoHideHeader: false, // auto hide header
  fixSiderbar: true // sticky siderbar
}
