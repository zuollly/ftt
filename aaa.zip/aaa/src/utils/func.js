/**
 * @description 函数功能描述：
 * 原数组：
 * [{ key: '学习任务', keyDesc: '学习环节得分项目' },
 *  { key: '学习任务', keyDesc: '学习总时长得分项目' },
 *  { key: '学习任务', keyDesc: '学习有效时长得分项目' },
 *  { key: '作业成绩', keyDesc: '提交作业数量' },
 *  { key: '作业成绩', keyDesc: '提交优秀作业数量' },
 *  { key: '作业成绩', keyDesc: '批改作业数量' }
 * ]
 * @param {*原始数组} listUnique
 * @return
 * [
 *  { key: '学习任务', keyList: ['学习环节得分项目', '学习总时长得分项目', '学习有效时长得分项目'] },
 *  { key: '作业成绩', keyList: ['提交作业数量', '提交优秀作业数量', '批改作业数量'] }
 * ]
 */
export function getMergeList(listUnique) {
  const map = {}
  const dest = []
  for (let i = 0; i < listUnique.length; i++) {
    const ai = listUnique[i]
    if (!map[ai.pKey]) {
      dest.push({ pKey: ai.pKey, data: [ai.key] })
      map[ai.pKey] = ai
    } else {
      for (let j = 0; j < dest.length; j++) {
        const dj = dest[j]
        if (dj.pKey === ai.pKey) {
          if (!~dj.data.indexOf(ai.key)) {
            dj.data.push(ai.key)
          }
          break
        }
      }
    }
  }
  return dest
}
/**
 * @description 原始数组为二维数组 其余同上一函数
 * @param {*} listUnique
 */
export function getMergeObjectList(listUnique) {
  const map = {}
  const dest = []
  for (let i = 0; i < listUnique.length; i++) {
    const ai = listUnique[i]
    if (!map[ai.behaviorCode]) {
      dest.push({ behaviorCode: ai.behaviorCode, maxScore: ai.maxScore, behaviorScores: ai.behaviorScores })
      map[ai.behaviorCode] = ai
    } else {
      for (let j = 0; j < dest.length; j++) {
        const dj = dest[j]
        if (dj.behaviorCode === ai.behaviorCode) {
          // if (!~dj.data.indexOf(ai.key)) {
          dj.behaviorScores = dj.behaviorScores.concat(ai.behaviorScores)
          // }
          break
        }
      }
    }
  }
  return dest
}
export function compare(property) {
  return function(a, b) {
    var value1 = a[property]
    var value2 = b[property]
    return value1 - value2
  }
}
// for (let j = 0; j <= params.length - 1; j++) {
//   if (params[j].behaviorCode) {
//     for (let i = j + 1; i <= params.length - 1; i++) {
//       if (params[i].behaviorCode && (params[i].behaviorCode === params[j].behaviorCode)) {
//         params[j].behaviorScores = params[j].behaviorScores.concat(params[i].behaviorScores)
//         params.splice(i, 1, {})
//       } else {
//         break
//       }
//     }
//   }
// }
// const paramTemp = []
// for (const val of params) {
//   if (val.behaviorCode) {
//     paramTemp.push(val)
//   }
// }
// const dataParams = {
//   roleBehaviorVOs: paramTemp,
//   projectId: 11,
//   roleCode: '3232'
// }

/**
 *
 * @param {与上述函数的相反的函数} list
 */
// "roleBehaviorVOs": [
//   {
//     "id": "fe86e1345d51a97e7557598063b6cc92",
//     "assessmentRoleId": "e04ed2adb0116f89a8c79a7eca0e4e40",
//     "behaviorCode": "PBTD1_PABD1",
//     "behaviorName": "学习环节得分项目",
//     "maxScore": 100,
//     "behaviorScores": [
//       {
//         "id": "23d4ad95c1fa960a1c78ba8ade7dc7a0",
//         "roleBehaviorId": "fe86e1345d51a97e7557598063b6cc92",
//         "scoreType": 2,
//         "minLimit": 10,
//         "maxLimit": 22,
//         "score": null,
//         "sort": 0
//       },
//       {
//         "id": "8f75464c91bfb6eff3c1da2e2dbfbfd8",
//         "roleBehaviorId": "fe86e1345d51a97e7557598063b6cc92",
//         "scoreType": 2,
//         "minLimit": 2,
//         "maxLimit": 33,
//         "score": null,
//         "sort": 0
//       },
//       {
//         "id": "f610171c3b797381058c5ed1316d2b69",
//         "roleBehaviorId": "fe86e1345d51a97e7557598063b6cc92",
//         "scoreType": 2,
//         "minLimit": 1,
//         "maxLimit": 43,
//         "score": null,
//         "sort": 0
//       }
//     ]
//   }
// ]
export function getResolutionObjectList(listUnique) {
  console.log(listUnique, 'listUnique----------')
  const dest = []
  for (let j = 0; j < listUnique.length; j++) {
    for (let i = 0; i < listUnique[j].behaviorScores.length; i++) {
      dest.push({
        behaviorCode: listUnique[j].behaviorCode,
        behaviorIntroduction: listUnique[j].behaviorName,
        // behaviorSort: 1,
        behaviorTypeCode: listUnique[j].behaviorTypeCode,
        key: listUnique[j].behaviorTypeName,
        keyDesc: listUnique[j].behaviorName,
        maxLimit: listUnique[j].behaviorScores[i].maxLimit,
        maxScore: listUnique[j].maxScore,
        minLimit: listUnique[j].behaviorScores[i].minLimit,
        score: listUnique[j].behaviorScores[i].score,
        scoreType: listUnique[j].behaviorScores[i].scoreType,
        sort: listUnique[j].behaviorScores[i].sort,
        value: Math.random()
      })
    }
  }
  return dest
}

/**
 * @description 将得到的数组通过给其添加一些属性（ifshow）构造为一组可以按照自定义table方式显示的数据
 * @param {*原始list} list
 * @return 构造list
 */
export function listHandle(list) {
  // list = list.sort(compare('sort'))
  // const tempRecord = {}
  for (const key in list[0]) {
    let k = 0
    while (k < list.length) {
      list[k].index = k + 1
      list[k][key + 'count'] = 1
      list[k][key + 'show'] = true
      // tempRecord[list[k].key] = tempRecord[list[k].key] ? tempRecord[list[k].key]++ : 1
      for (var i = k + 1; i <= list.length - 1; i++) {
        if (list[k][key] === list[i][key] && list[k][key] !== '') {
          list[k][key + 'count']++
          list[k][key + 'show'] = true
          list[i][key + 'count'] = 1
          list[i][key + 'show'] = false
        } else {
          break
        }
      }
      if (key === 'keyDesc') {
        list[i - 1][key + 'times'] = '999'
      }
      k = i
    }
  }
  console.log(list)
  return list
}

export function uniqueArr(arr) {
  const res = new Map()
  return arr.filter((a) => !res.has(a.courseId) && res.set(a.courseId, 1))
}
