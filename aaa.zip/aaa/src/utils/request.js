import axios from 'axios'
import { Message } from 'element-ui'
// import store from '@/store'
import { getToken } from '@/utils/storage/cookies'
const codeMessage = {
  200: '服务器成功返回请求的数据。',
  201: '新建或修改数据成功。',
  202: '一个请求已经进入后台排队（异步任务）。',
  204: '删除数据成功。',
  400: '发出的请求有错误，服务器没有进行新建或修改数据的操作。',
  401: '用户没有权限（令牌、用户名、密码错误）。',
  403: '用户得到授权，但是访问是被禁止的。',
  404: '发出的请求针对的是不存在的记录，服务器没有进行操作。',
  406: '请求的格式不可得。',
  410: '请求的资源被永久删除，且不会再得到的。',
  422: '当创建一个对象时，发生一个验证错误。',
  500: '服务器发生错误，请检查服务器。',
  502: '网关错误。',
  503: '服务不可用，服务器暂时过载或维护。',
  504: '网关超时。'
}
// create an axios instance
const service = axios.create({
  // baseURL: process.env.BASE_API, // api的base_url
  baseURL: 'http://yx.nercel.cn/msapi/',
  // baseURL: '/api',
  timeout: 30000 // request timeout
})
// request interceptor
service.interceptors.request.use(config => {
  // Do something before request is sent
  // console.log(store.getters.token)
  if (getToken()) {
    config.headers['Authorization'] = 'Bearer ' + getToken() // 让每个请求携带token-- ['X-Token']为自定义key 请根据实际情况自行修改
  }
  // config.headers['Authorization'] = 'Bearer a190d6e1-78e4-4c99-8605-a8b0eb706cca'
  console.log(config, 'config----------------')
  return config
}, error => {
  // Do something with request error
  console.log(error) // for debug
  Promise.reject(error)
})
// respone interceptor
service.interceptors.response.use(
  response => response,
  /**
   * 下面的注释为通过response自定义code来标示请求状态，当code返回如下情况为权限有问题，登出并返回到登录页
   * 如通过xmlhttprequest 状态码标识 逻辑可写在下面error中
   */
  // const res = response.data;
  //  if (res.code !== 20000) {
  //    Message({
  //      message: res.message,
  //      type: 'error',
  //      duration: 5 * 1000
  //    });
  //    // 50008:非法的token; 50012:其他客户端登录了;  50014:Token 过期了;
  //    if (res.code === 50008 || res.code === 50012 || res.code === 50014) {
  //      MessageBox.confirm('你已被登出，可以取消继续留在该页面，或者重新登录', '确定登出', {
  //        confirmButtonText: '重新登录',
  //        cancelButtonText: '取消',
  //        type: 'warning'
  //      }).then(() => {
  //        store.dispatch('FedLogOut').then(() => {
  //          location.reload();// 为了重新实例化vue-router对象 避免bug
  //        });
  //      })
  //    }
  //    return Promise.reject('error');
  //  } else {
  //    return response.data;
  //  }
  error => {
    console.log('err' + error)// for debug
    if (error.config.url.indexOf('/oauth/token') < 0) {
      Message({
        message: codeMessage[error.response.status],
        type: 'error',
        duration: 2 * 1000
      })
    }
    // if (error.response.status === 401 && store.getters.environment) {
    //   window.location.href = 'http://rrt.xjbtedu.cn/'
    // }
    return Promise.reject(error)
  })

export default service
