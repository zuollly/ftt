const getters = {
  // 前端静态信息设置
  appConfig: state => state.app.appConfig, // 全局在前端调整的信息
  themeConfig: state => state.app.themeConfig, // 网站主题设置
  openSidebar: state => state.app.openSidebar, // 左侧菜单默认显示或隐藏
  themeColor: state => state.app.themeColor, // 网站主色调
  currentRoute: state => state.app.currentRoute, // 当前路由地址
  browserInfo: state => state.app.browserInfo, // 当前浏览器信息
  containerName: state => state.app.containerName, // 根据当前客户端浏览器宽度，给body设置一个className
  isMobile: state => state.app.isMobile, // 是否是手机
  // 系统
  sysBasicConfig: state => state.globalSet.sysBasicConfig, // 系统全局基本设置
  sysCoreConfig: state => state.globalSet.sysCoreConfig, // 系统全局核心设置
  sysAffixConfig: state => state.globalSet.sysAffixConfig, // 系统全局附件设置
  sysMemberConfig: state => state.globalSet.sysMemberConfig, // 系统全局会员设置
  sysInteractConfig: state => state.globalSet.sysInteractConfig, // 系统全局互动设置
  sysSpeedConfig: state => state.globalSet.sysSpeedConfig, // 系统全局性能设置
  sysOtherConfig: state => state.globalSet.sysOtherConfig, // 系统全局其它设置
  sysModuleConfig: state => state.globalSet.sysModuleConfig, // 系统全局模块设置
  // 用户
  uuid: state => state.user.uuid, // 登录用户ID
  userCode: state => state.user.userCode, // 登录用户code
  userID: state => state.user.userID, // 登录用户帐户ID
  token: state => state.user.token, // 登录用户登录Token
  userAvatar: state => state.user.userAvatar, // 登录用户头像
  userName: state => state.user.userName, // 登录用户昵称
  userIntroduction: state => state.user.introduction, // 登录用户简介
  userStatus: state => state.user.userStatus, // 登录用户状态
  userRoles: state => state.user.userRoles, // 登录用户角色
  userRolePower: state => state.user.userRolePower,
  userSetting: state => state.user.setting, // 登录用户个人的一设置，权限，等
  // 字典表
  studyPhaseList: state => state.dict.studyPhaseList, // 学段
  subjectList: state => state.dict.subjectList, // 学科
  gradeList: state => state.dict.gradeList, // 年级
  educationList: state => state.dict.educationList, // 学历
  schoolList: state => state.dict.schoolList, // 学校
  graduateSchoolList: state => state.dict.graduateSchoolList, // 毕业院校
  majorList: state => state.dict.majorList, // 专业
  nationList: state => state.dict.nationList, // 民族
  politicsList: state => state.dict.politicsList, // 政治面貌
  sexList: state => state.dict.sexList, // 性别
  workUnitList: state => state.dict.workUnitList, // 单位
  occupationList: state => state.dict.occupationList, // 职业
  professionalLevelList: state => state.dict.professionalLevelList, // 职业级别
  // 项目是否接入兵团
  environment: state => state.env.isXJBT
}
export default getters
