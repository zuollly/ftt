import locals from '@/utils/storage/locals'
// navTheme: 'dark', // 整体风格设置（导航背景）
// primaryColor: '#1890FF', // 主题颜色
// layout: 'sidemenu ｜ topmenu', // 导航模式
// contentWidth: 'Fluid', // 内容区域宽度 如果当前导航模式为sidemenu哪么只能是流式，如果是topmenu哪可以选择定宽或流式 layout of content: Fluid or Fixed, only works when layout is topmenu
// fixedHeader: false, // sticky header 固定头部
// autoHideHeader: false, // auto hide header 下滑时隐藏顶部
// fixSiderbar: false, // sticky siderbar 让sidemenu固定高度出现滚动条
const app = {
  state: {
    appConfig: locals.getItem('appConfig'), // 系统全局设置
    themeConfig: locals.getItem('themeConfig'), // 网站布局设置
    openSidebar: !+locals.getItem('sidebarStatus'), // 网站左侧导航状态
    themeColor: '',
    currentRoute: '', // 当前路由地址
    browserInfo: '', // 用户浏览器信息
    containerName: '', // 根据当前客户端浏览器宽度，给body设置一个className
    isMobile: '' // 当前客户端是否是手机
  },
  mutations: {
    SET_APPCONFIG: (state, param) => {
      locals.setItem('appConfig', param)
      state.appConfig = locals.getItem('appConfig')
    },
    SET_THEMEPARAM: (state, param) => {
      locals.setItem('themeConfig', param)
      state.themeConfig = locals.getItem('themeConfig')
    },
    TOGGLE_SIDEBAR: (state) => {
      if (state.openSidebar) {
        locals.setItem('sidebarStatus', 1)
      } else {
        locals.setItem('sidebarStatus', 0)
      }
      state.openSidebar = !state.openSidebar
    },

    SET_THEMECOLOR: (state, themeColor) => {
      state.themeColor = themeColor
    },
    SET_CURRENTROUTE: (state, currentRoute) => {
      state.currentRoute = currentRoute
    },
    SET_BROWSERINFO: (state, browserInfo) => {
      state.browserInfo = browserInfo
    },
    SET_CONTAINERNAME: (state, containerName) => {
      state.containerName = containerName
    },
    SET_ISMOBILE: (state, isMobile) => {
      state.isMobile = isMobile
    }
  },
  actions: {
    SetAppConfig({ commit }, param) {
      commit('SET_APPCONFIG', param)
    },
    setThemeParam({ commit }, param) {
      commit('SET_THEMEPARAM', param)
    },
    toggleSideBar({ commit }) {
      commit('TOGGLE_SIDEBAR')
    },
    SetThemeColor({ commit }, themeColor) {
      commit('SET_THEMECOLOR', themeColor)
    },
    SetCurrentRoute({ commit }, currentRoute) {
      commit('SET_CURRENTROUTE', currentRoute)
    },
    SetBrowserInfo({ commit }, browserInfo) {
      commit('SET_BROWSERINFO', browserInfo)
    },
    SetContainerName({ commit }, containerName) {
      commit('SET_CONTAINERNAME', containerName)
    },
    SetIsMobile({ commit }, isMobile) {
      commit('SET_ISMOBILE', isMobile)
    }
  }
}

export default app
