// import locals from '@/utils/storage/locals'
import { fetchGlobalConfig } from '@/api/global'
const globalSet = {
  state: {
    sysBasicConfig: '', // 系统全局基本设置
    sysCoreConfig: '', // 系统全局核心设置
    sysAffixConfig: '', // 系统全局附件设置
    sysMemberConfig: '', // 系统全局会员设置
    sysInteractConfig: '', // 系统全局互动设置
    sysSpeedConfig: '', // 系统全局性能设置
    sysOtherConfig: '', // 系统全局其它设置
    sysModuleConfig: '' // 系统全局模块设置
  },
  mutations: {
    SET_SYSBASICCONFIG: (state, param) => {
      // locals.setItem('sysBasicConfig', param)
      state.sysBasicConfig = param
    },
    SET_SYSCORECONFIG: (state, param) => {
      // locals.setItem('sysCoreConfig', param)
      state.sysCoreConfig = param
    },
    SET_SYSAFFIXCONFIG: (state, param) => {
      // locals.setItem('sysAffixConfig', param)
      state.sysAffixConfig = param
    },
    SET_SYSMEMBERCONFIG: (state, param) => {
      // locals.setItem('sysMemberConfig', param)
      state.sysMemberConfig = param
    },
    SET_SYSINTERACTCONFIG: (state, param) => {
      // locals.setItem('sysInteractConfig', param)
      state.sysInteractConfig = param
    },
    SET_SYSSPEEDCONFIG: (state, param) => {
      // locals.setItem('sysSpeedConfig', param)
      state.sysSpeedConfig = param
    },
    SET_SYSOTHERCONFIG: (state, param) => {
      // locals.setItem('sysOtherConfig', param)
      state.sysOtherConfig = param
    },
    SET_SYSMODULECONFIG: (state, param) => {
      // locals.setItem('sysModuleConfig', param)
      state.sysModuleConfig = param
    }
  },
  actions: {
    getSysConfig({ commit }, param) {
      return new Promise((resolve, reject) => {
        fetchGlobalConfig(param).then(response => {
          const data = response.data.result
          const config = {}
          for (var i = 0; i < data.length; i++) {
            config[data[i].varname] = data[i].value
          }
          if (param.groupid === 1) commit('SET_SYSBASICCONFIG', config)
          if (param.groupid === 2) commit('SET_SYSCORECONFIG', config)
          if (param.groupid === 3) commit('SET_SYSAFFIXCONFIG', config)
          if (param.groupid === 4) commit('SET_SYSMEMBERCONFIG', config)
          if (param.groupid === 5) commit('SET_SYSINTERACTCONFIG', config)
          if (param.groupid === 6) commit('SET_SYSSPEEDCONFIG', config)
          if (param.groupid === 7) commit('SET_SYSOTHERCONFIG', config)
          if (param.groupid === 8) commit('SET_SYSMODULECONFIG', config)
          resolve()
        }).catch(error => {
          reject(error)
        })
      })
    }
  }
}

export default globalSet
