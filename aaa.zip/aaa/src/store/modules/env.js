/**
 * 此项目有两种应用场景
 *   一是接入新疆兵团, 那么在项目从兵团跳转过来的时候url上便会带有token, 因此,这种是不需要登录功能的
 *   二是独自是一套系统, 有自己的登录, 不需要从外部过来
 *  因此我设置一个全局的变量 isXJBT 来判断用哪一种
 */
// const env = {
//   state: {
//     isXJBT: false // 为 true 则是兵团接入
//   }
// }
// export default env

import * as appConfig from '../../../static/appConfig'
const env = {
  state: {
    isXJBT: appConfig.app_isXJBT // 为 true 则是兵团接入
  }
}
export default env

