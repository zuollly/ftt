// 字典表
const dictData = {
  state: {
    studyPhaseList: [], // 学段
    subjectList: [], // 学科
    gradeList: [], // 年级
    educationList: [], // 学历
    schoolList: [], // 学校
    graduateSchoolList: [], // 毕业院校
    majorList: [], // 专业
    nationList: [], // 民族
    politicsList: [], // 政治面貌
    sexList: [], // 性别
    workUnitList: [], // 单位
    occupationList: [], // 职业
    professionalLevelList: [] // 职业级别
  },
  mutations: {
    SET_STUDYPHASE: (state, data) => {
      state.studyPhaseList = data
    },
    SET_SUBJECT: (state, data) => {
      state.subjectList = data
    },
    SET_GRADE: (state, data) => {
      state.gradeList = data
    },
    SET_EDUCATION: (state, data) => {
      state.educationList = data
    },
    SET_SCHOOL: (state, data) => {
      state.schoolList = data
    },
    SET_GRADUATESCHOOL: (state, data) => {
      state.graduateSchoolList = data
    },
    SET_MAJORIN: (state, data) => {
      state.majorList = data
    },
    SET_NATION: (state, data) => {
      state.nationList = data
    },
    SET_POLITICS: (state, data) => {
      state.politicsList = data
    },
    SET_SEX: (state, data) => {
      state.sexList = data
    },
    SET_WORKUNIT: (state, data) => {
      state.workUnitList = data
    },
    SET_OCUPATION: (state, data) => {
      state.occupationList = data
    },
    SET_PROFESSIONAL: (state, data) => {
      state.professionalLevelList = data
    }
  },
  actions: {
    getStudyPhaseList({ commit }, data) {
      commit('SET_STUDYPHASE', data)
    },
    getSubjectList({ commit }, data) {
      commit('SET_SUBJECT', data)
    },
    getGradeList({ commit }, data) {
      commit('SET_GRADE', data)
    },
    getEducationList({ commit }, data) {
      commit('SET_EDUCATION', data)
    },
    getSchoolList({ commit }, data) {
      commit('SET_SCHOOL', data)
    },
    getGraduateSchoolList({ commit }, data) {
      commit('SET_GRADUATESCHOOL', data)
    },
    getMajorList({ commit }, data) {
      commit('SET_MAJORIN', data)
    },
    getNationList({ commit }, data) {
      commit('SET_NATION', data)
    },
    getPoliticsList({ commit }, data) {
      commit('SET_POLITICS', data)
    },
    getSexList({ commit }, data) {
      commit('SET_SEX', data)
    },
    getWorkUnitList({ commit }, data) {
      commit('SET_WORKUNIT', data)
    },
    getOccupationList({ commit }, data) {
      commit('SET_OCUPATION', data)
    },
    getProfessionalLevelList({ commit }, data) {
      commit('SET_PROFESSIONAL', data)
    }
  }
}

export default dictData
