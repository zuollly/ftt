import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'
import app from './modules/app'
import globalSet from './modules/globalSet'
import user from './modules/user'
import dict from './modules/dict'
import env from './modules/env'
Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app, globalSet, user, dict, env
  },
  getters
})

export default store
