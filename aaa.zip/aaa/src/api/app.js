// 整体全局的
// 公用api
import request from '@/utils/request.js' // 引用request.js
// 查询全局配置数据
export function fetchGlobalConfig(data) {
  return request({
    url: '/tool/sysconfig/queryAll',
    method: 'get',
    params: data
  })
}
// 查询出分组类的字典记录
export function fetchDictList(data) {
  return request({
    url: '/dict/queryAll',
    method: 'get',
    params: data
  })
}
