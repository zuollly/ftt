import request from '@/utils/request.js' // 引用request.js
export function uploadImg(data) {
  return request({
    url: `/pxlite/sourceHandle/upload`,
    method: 'post',
    data
  })
}
// 新建项目
export function insertPxProject(data) {
  return request({
    url: `/project/insert`,
    method: 'post',
    data: data
  })
}
// 根据id查询项目详情
export function fetchPxProjectInfo(data) {
  return request({
    url: `/project/queryOne`,
    method: 'get',
    params: data
  })
}
// 新增计划
export function insertPxProjectPlan(data) {
  return request({
    url: `/project/stageStep/plan/insert`,
    method: 'post',
    data: data
  })
}
// 编辑计划
export function updatePxProjectPlan(data) {
  return request({
    url: `/project/stageStep/plan/update`,
    method: 'post',
    data: data
  })
}
// 查询所有计划
export function fetchPxProjectPlan(data) {
  return request({
    url: `/project/stageStep/plan/queryAll`,
    method: 'get',
    params: data
  })
}
// 修改项目信息
export function updatePxProject(data) {
  return request({
    url: `/project/update`,
    method: 'put',
    data: data
  })
}
// 条件分页查询项目列表
export function fetchPxProjectPage(data) {
  return request({
    url: `/project/queryPage`,
    method: 'POST',
    data: data
  })
}
// 根据id删除项目（支持批量删除）
export function deletePagePxProject(data) {
  return request({
    url: `/project/delete`,
    method: 'delete',
    data: data
  })
}
// 查询所有环节要求字典类
export function fetchRequirementDict(data) {
  return request({
    url: `/project/requirementDict/queryAll`,
    method: 'get',
    params: data
  })
}

// 新增阶段
export function insertStageStep(data) {
  return request({
    url: `/project/stageStep/stage/insert`,
    method: 'post',
    data: data
  })
}
// 编辑阶段
export function updateStageStep(data) {
  return request({
    url: `/project/stageStep/stage/update`,
    method: 'post',
    data: data
  })
}
// 删除阶段
export function deleteStageStep(data) {
  return request({
    url: `/project/stageStep/stage/delete`,
    method: 'delete',
    data: data
  })
}
// 根据ID查询阶段详情
export function fetchOneStageStepDetails(data) {
  return request({
    url: `/project/stageStep/stage/queryOne`,
    method: 'get',
    params: data
  })
}
// 查询所有阶段
export function fetchStageStep(data) {
  return request({
    url: `/project/stageStep/stage/queryAll`,
    method: 'get',
    params: data
  })
}

// 新增环节
export function insertStageStepStep(data) {
  return request({
    url: `/project/stageStep/step/insert`,
    method: 'post',
    data: data
  })
}
// 新增环节(批量)
export function insertXKStageStepStep(data) {
  return request({
    url: `/project/stageStep/step/insertXK`,
    method: 'post',
    data: data
  })
}
// 删除环节
export function deleteStageStepStep(data) {
  return request({
    url: `/project/stageStep/step/delete`,
    method: 'delete',
    data: data
  })
}
// 新增环节内容
export function insertStepCourseContent(data) {
  return request({
    url: `/project/stageStep/stepContent/insert`,
    method: 'post',
    data: data
  })
}
// 编辑环节内容
export function updateStepCourseContent(data) {
  return request({
    url: `/project/stageStep/stepContent/update`,
    method: 'post',
    data: data
  })
}
// 删除环节内容
export function deleteStepCourseContent(data) {
  return request({
    url: `/project/stageStep/stepContent/delete`,
    method: 'delete',
    data: data
  })
}
// 查询所有环节内容
export function fetchStepCourseContent(data) {
  return request({
    url: `/project/stageStep/stepContent/queryAll`,
    method: 'get',
    params: data
  })
}
// 新增环节要求
export function insertStageStepRequirement(data) {
  return request({
    url: `/project/stageStep/stepRequirement/insert`,
    method: 'post',
    data: data
  })
}
// 查询所有环节要求
export function fetchStageStepRequirement(data) {
  return request({
    url: `/project/stageStep/stepRequirement/queryAll`,
    method: 'get',
    params: data
  })
}
// 删除环节要求
export function deleteStageStepRequirement(data) {
  return request({
    url: `/project/stageStep/stepRequirement/delete`,
    method: 'delete',
    data: data
  })
}
// 编辑环节要求
export function updateStageStepRequirement(data) {
  return request({
    url: `/project/stageStep/stepRequirement/update`,
    method: 'post',
    data: data
  })
}
// 编辑环节
export function updataStageStepStep(data) {
  return request({
    url: `/project/stageStep/step/update`,
    method: 'post',
    data: data
  })
}
// 查询所有环节
export function fetchStageStepStep(data) {
  return request({
    url: `/project/stageStep/step/query`,
    method: 'get',
    params: data
  })
}
// 根据ID查询环节
export function fetchOneStageStepStep(data) {
  return request({
    url: `/project/stageStep/step/queryOne`,
    method: 'get',
    params: data
  })
}
// 查询所有环节类型字典类
export function fetchStepTypeDict(data) {
  return request({
    url: `/project/stepTypeDict/queryAll`,
    method: 'get',
    params: data
  })
}

// 项目分类
// 新建项目类型
export function insertPxProjectType(data) {
  return request({
    url: `/project/type/insert`,
    method: 'post',
    data: data
  })
}
// 修改项目类型信息
export function updatePxProjectType(data) {
  return request({
    url: `/project/type/update`,
    method: 'put',
    data: data
  })
}
// 条件分页查询项目类型列表
export function fetchPxProjectTypePage(data) {
  return request({
    url: `/project/type/queryPage`,
    method: 'get',
    params: data
  })
}
// 查询所有的项目类型
export function fetchPxProjectType(data) {
  return request({
    url: `/project/type/queryAll`,
    method: 'get',
    params: data
  })
}
// 根据id删除项目类型（支持批量删除）
export function deletePagePxProjectType(data) {
  return request({
    url: `/project/type/delete`,
    method: 'delete',
    data: data
  })
}

// 获取考核行为可选择数据
export function getBehaviorDictData(data) {
  return request({
    url: `/project/assessmentBehavior/getBehaviorDictData`,
    method: 'get',
    params: data
  })
}
// 插入角色行为得分绑定实体请求
export function insertRoleBehavior(data) {
  return request({
    url: `/project/assessmentBehavior/roleBehavior/insert`,
    method: 'post',
    data: data
  })
}
// 编辑角色行为得分绑定实体请求
export function updateRoleBehavior(data) {
  return request({
    url: `/project/assessmentBehavior/roleBehavior/update`,
    method: 'post',
    data: data
  })
}
// 根据角色绑定ID获取角色行为得分情况
export function fetchRoleBehavior(data) {
  return request({
    url: `/project/assessmentBehavior/roleBehavior/queryOneById`,
    method: 'get',
    params: data
  })
}
// 根据项目ID和角色CODE获取角色行为得分情况
export function fetchOneByProjectIdAndRoleCode(data) {
  return request({
    url: `/project/assessmentBehavior/roleBehavior/queryOneByProjectIdAndRoleCode`,
    method: 'get',
    params: data
  })
}

// 项目批量导入用户（返回的result不为空的话，result里就是失败项的集合）
export function insertUserBatch(data, userId, projectId) {
  return request({
    url: `/user/project/insert/import?userId=${userId}&projectId=${projectId}`,
    method: 'post',
    data: data
  })
}

// 翻页查询成员
export function fetchUserpage(data) {
  return request({
    url: `/user/userRole/queryPage`,
    method: 'post',
    data: data
  })
}
// 添加专家信息
export function addExpert(data) {
  return request({
    url: `/user/userRole/insertExpert`,
    method: 'post',
    data: data
  })
}
// 修改用户角色
export function updateExpert(data) {
  return request({
    url: `/user/userRole/update`,
    method: 'post',
    data: data
  })
}
// 翻页查询成员(项目用户管理)
export function fetchProjectUserpage(data) {
  return request({
    url: `/user/project/queryPage`,
    method: 'post',
    data: data
  })
}

// 添加成员，支持批量添加
export function insertProjectUserBatch(data) {
  return request({
    url: `/user/project/insert/batch`,
    method: 'post',
    data: data
  })
}

// 根据ID删除某个范围内的成员（支持批量删除）
export function deleteProjectUser(data) {
  return request({
    url: `/user/project/delete`,
    method: 'post',
    data: data
  })
}
// 自动生成各级管理员
export function insertProjectManager(data) {
  return request({
    url: `/user/project/insert/manager/auto`,
    method: 'get',
    params: data
  })
}
export function fetchUserRole(query) {
  return request({
    url: '/user/role/queryAll',
    method: 'GET',
    params: query
  })
}
// 根据多条件查询某个范围所有角色
export function fetchUserRoleByCondtion(data) {
  return request({
    url: `/user/role/queryAll`,
    method: 'post',
    data: data
  })
}
// 从培训计划新增待选课或者批量新增必修课环节
export function insertCourseToStep(data) {
  return request({
    url: '/project/stageStep/step/insertFromPlan',
    method: 'post',
    data: data
  })
}
// 根据项目Id获取项目内成员成绩
export function fetchUserScores(query) {
  return request({
    url: '/project/assessGetScore/getUserScores',
    method: 'GET',
    params: query
  })
}
