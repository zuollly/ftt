import request from '@/utils/request'

// 分页查询字典分组
export function fetchDictTypePage(data) {
  return request({
    url: '/type/queryPage',
    method: 'get',
    params: data
  })
}
// 添加一条字典分组
export function insertDictTypeItem(data) {
  return request({
    url: '/type/add',
    method: 'post',
    data: data
  })
}
// updata
export function updateDictTypeItem(data) {
  return request({
    url: '/dict/type/update',
    method: 'put',
    data: data
  })
}
// delete
export function deleteDictTypeItem(data) {
  return request({
    url: '/type/delete',
    method: 'delete',
    data: data
  })
}
// 查询出分组类的字典记录
export function fetchDictList(data) {
  return request({
    url: '/dict/queryAll',
    method: 'get',
    params: data
  })
}
// 根据Id更新一条字典数据记录【完全更新】
export function updateDict(data) {
  return request({
    url: '/dict/update',
    method: 'put',
    data: data
  })
}
// 根据id批量删除字典记录
export function deleteDict(data) {
  return request({
    url: '/dict/delete',
    method: 'delete',
    data: data
  })
}
// 添加一条字典数据记录
export function insertDict(data) {
  return request({
    url: '/dict/add',
    method: 'post',
    data: data
  })
}

// 字典绑定关系
// 分页查询关联记录
export function fetchDictRelationListPage(data) {
  return request({
    url: '/relation/queryPage',
    method: 'get',
    params: data
  })
}
// 根据学段查学科
export function dictRelation(params) {
  return request({
    url: '/relation/queryByKey',
    method: 'get',
    params
  })
}
// 批量查询绑定关系
export function queryDictRelation(data) {
  return request({
    url: '/relation/queryRelation',
    method: 'post',
    data
  })
}

// 分页查询字典关联分组
export function getDictRelationPage(data) {
  return request({
    url: '/group/queryPage',
    method: 'get',
    params: data
  })
}

// 批量添加字典关联分组
export function addDictGroupBatch(data) {
  return request({
    url: '/group/add',
    method: 'POST',
    data: data
  })
}

// 根据Id批量删除关联分组
export function deleteGroupBatch(data) {
  return request({
    url: '/group/delete',
    method: 'DELETE',
    data: data
  })
}

// 查询全部关联记录
export function getGroupRelation(query) {
  return request({
    url: '/relation/queryAll',
    method: 'GET',
    params: query
  })
}

// 根据id批量更新关联记录
export function updateRelationBatch(data) {
  return request({
    url: '/relation/update',
    method: 'PUT',
    data: data
  })
}

// 根据key查询绑定关系
export function getRelationByKey(query) {
  return request({
    url: '/relation/queryByKey',
    method: 'GET',
    params: query
  })
}

// 全部查询字典数据
export function fetchDictInfo(data) {
  return request({
    url: '/tool/dict/queryAll',
    method: 'GET', // 请求方法
    params: data
  })
}

