import request from '@/utils/request'

// 删除工作坊（支持批量删除）
export function deleteGroup(query) {
  return request({
    url: '/workshop/group/delete',
    method: 'delete',
    data: query
  })
}

// 新建工作坊
export function insertGroup(query) {
  return request({
    url: '/workshop/group/insert',
    method: 'post',
    data: query
  })
}
// 条件分页查询工作坊列表
export function fetchGroupPage(query) {
  return request({
    url: '/workshop/group/queryList',
    method: 'post',
    data: query
  })
}
// 修改工作坊信息
export function updateGroup(query) {
  return request({
    url: '/workshop/group/update',
    method: 'put',
    data: query
  })
}

// 根据id获取工作坊信息
export function fetchGroup(query) {
  return request({
    url: '/workshop/group/queryById',
    method: 'get',
    params: query
  })
}

// 工作坊分类

// 新建
export function insertGroupType(data) {
  return request({
    url: '/workshop/jyGroupTypeDict/insert',
    method: 'post',
    data: data
  })
}
// 根据id删除（支持批量删除）
export function deleteGroupType(data) {
  return request({
    url: '/workshop/jyGroupTypeDict/delete',
    method: 'delete',
    data: data
  })
}
// 修改
export function updateGroupType(data) {
  return request({
    url: '/workshop/jyGroupTypeDict/update',
    method: 'put',
    data: data
  })
}
// 条件分页查询
export function fetchGroupTypePage(data) {
  return request({
    url: '/workshop/jyGroupTypeDict/queryPage',
    method: 'post',
    data: data
  })
}
// 根据code查询联动关系
export function getArea(code) {
  return request({
    url: `/districtController/getByParentCode?code=${code}`,
    method: 'GET'
  })
}
// 根据code查询联动关系
export function getSchool(data) {
  return request({
    url: `/schoolController/selectListBySchool`,
    method: 'GET',
    params: data
  })
}
// 根据code查询联动关系
export function getTeacherList(data) {
  return request({
    url: `/userInfo/selectTeacherOrStudentInSchool`,
    method: 'post',
    data: data
  })
}

export function fetchActivityFromGroup(data) {
  return request({
    url: `/workshop/group/queryActivityFromGroup`,
    method: 'get',
    params: data
  })
}
