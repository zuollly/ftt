import request from '@/utils/request'

// 会员列表
export function fetchMemberPage(data) {
  return request({
    url: '/user/queryPage',
    method: 'post',
    data
  })
}
// 添加会员
export function insertMember(data) {
  return request({
    url: '/user/insert',
    method: 'post',
    data
  })
}
// 编辑会员
export function updateMember(data) {
  return request({
    url: '/user/update',
    method: 'post',
    data
  })
}
// 删除会员
export function deleteMember(data) {
  return request({
    url: '/user/delete',
    method: 'post',
    data
  })
}
// 会员详情
export function fetchMemberById(data) {
  return request({
    url: '/user/queryInfo',
    method: 'post',
    data
  })
}
// 批量添加
export function insertMemberBatch(data) {
  return request({
    url: '/user/insert/batch',
    method: 'post',
    data
  })
}

// 查询所有成员
export function fetchProjectMember(data) {
  return request({
    url: '/user/project/queryAll',
    method: 'post',
    data
  })
}

// 根据多条件翻页查询成员
export function fetchProjectMemberPage(data) {
  return request({
    url: '/user/project/queryPage',
    method: 'post',
    data
  })
}

// 新增各级管理员
export function insertProjectManager(data) {
  return request({
    url: '/user/project/insert/manager',
    method: 'post',
    data
  })
}

// 修改用户在某个范围内的角色（支持批量修改）
export function updateProjectMember(data) {
  return request({
    url: '/user/project/updateRole',
    method: 'post',
    data
  })
}

// 根据ID删除某个范围内的成员（支持批量删除）
export function deleteProjectMember(data) {
  return request({
    url: '/user/project/delete',
    method: 'post',
    data
  })
}

// 从班级里删掉用户
export function deleteProjectClassMember(data) {
  return request({
    url: '/user/project/delete/class',
    method: 'post',
    data
  })
}

// 把待分配用户添加到班级
export function insertProjectClassMember(data) {
  return request({
    url: '/user/project/insert/class',
    method: 'post',
    data
  })
}
