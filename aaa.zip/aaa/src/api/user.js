// 与用户所在模块角色相关的
import request from '@/utils/request'
// 用户名登录
export function fetchUserRole(data) {
  return request({
    url: '/user/project/queryRole',
    method: 'post',
    data: data // { projectId: 'string', roleScopeId: 'string', userId: 'string } // projectId关联项目ID，默认为0表示项目外用户 roleScopeId 角色作用域ID（例如班级ID、工作坊ID） userId 登录用户ID
  })
}

// 获取用户权限值
export function fetchUserRolePower(data) {
  return request({
    url: '/user/project/queryRole/permission/kv',
    method: 'post',
    data: data // { projectId: 'string', roleScopeId: 'string', userId: 'string } // projectId关联项目ID，默认为0表示项目外用户 roleScopeId 角色作用域ID（例如班级ID、工作坊ID） userId 登录用户ID
  })
}
