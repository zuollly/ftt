import request from '@/utils/request'

// 查询全局配置数据
export function fetchGlobalConfig(data) {
  return request({
    url: '/tool/sysconfig/queryAll',
    method: 'get',
    params: data
  })
}

// 添加一项全局配置
export function insertGlobalConfig(data) {
  return request({
    url: '/globelconfig/insert',
    method: 'post',
    data
  })
}

// 删除数据全局配置
export function deleteGlobalConfig(data) {
  return request({
    url: '/globelconfig/delete',
    method: 'delete',
    data
  })
}

// 更新全局配置
export function updateGlobalConfig(data) {
  return request({
    url: '/globelconfig/update',
    method: 'put',
    data
  })
}
