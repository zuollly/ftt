import Vue from 'vue'
import Router from 'vue-router'
import BasicLayout from '@/views/layouts/BasicLayout'
import schoolRouter from './modules/school'
Vue.use(Router)

export const constantRouterMap = [
  { path: '/login', component: () => import('@/views/user/Login'), hidden: true },
  { path: '/register', component: () => import('@/views/user/Register'), hidden: true },
  { path: '/forget', component: () => import('@/views/user/Forget'), hidden: true },
  { path: '/403', component: () => import('@/views/exception/403'), hidden: true },
  { path: '/404', component: () => import('@/views/exception/404'), hidden: true },
  { path: '/500', component: () => import('@/views/exception/500'), hidden: true },
  schoolRouter,
  {
    path: '',
    component: BasicLayout,
    redirect: '/school/workshop/workshop-list',
    hidden: true
  },
  { path: '*', redirect: '/404', hidden: true }
]

export default new Router({
  // mode: 'history', // require service support
  routes: constantRouterMap
})

