import BasicLayout from '@/views/layouts/BasicLayout'
// 后台首页
const schoolRouter = {
  path: '/school',
  component: BasicLayout,
  redirect: '/school/kingdom',
  name: 'school',
  meta: { title: '首页', icon: 'school', noCache: true },
  children: [
    {
      path: 'workshop',
      component: () => import('@/views/layouts/LayRouter'),
      redirect: '/school/workshop/workshop-list',
      name: 'workshop',
      meta: { title: '工作室管理', icon: 'workshop', noCache: true },
      children: [
        {
          path: 'workshop-list', component: () => import('@/views/workshop/WorkshopList'), name: 'workshop-list', hidden: true, meta: { title: '工作室管理', icon: '' }},
        {
          path: 'workshop-add', component: () => import('@/views/workshop/WorkshopAdd'), name: 'workshop-add', hidden: true, meta: { title: '添加工作室', icon: '' }},
        {
          path: 'workshop-edit', component: () => import('@/views/workshop/WorkshopEdit'), name: 'workshop-edit', hidden: true, meta: { title: '编辑工作室', icon: '' }}
      ]
    }
    // {
    //   path: 'activity',
    //   component: () => import('@/views/layouts/LayRouter'),
    //   redirect: '/school/activity/activity-list',
    //   name: 'activity',
    //   meta: { title: '活动管理', icon: 'activity', noCache: true },
    //   children: [
    //     {
    //       path: 'activity-list', component: () => import('@/views/activity/ActivityList'), name: 'activity-list', hidden: true, meta: { title: '活动管理', icon: '' }},
    //     {
    //       path: 'activity-add', component: () => import('@/views/activity/ActivityAdd'), name: 'activity-add', hidden: true, meta: { title: '添加活动', icon: '' }},
    //     {
    //       path: 'activity-edit', component: () => import('@/views/activity/ActivityEdit'), name: 'activity-edit', hidden: true, meta: { title: '编辑活动', icon: '' }}
    //   ]
    // },
    // {
    //   path: 'doc',
    //   component: () => import('@/views/layouts/LayRouter'),
    //   redirect: '/school/doc/doc-list',
    //   name: 'doc',
    //   meta: { title: '资源管理', icon: 'doc', noCache: true },
    //   children: [
    //     {
    //       path: 'doc-list', component: () => import('@/views/doc/DocList'), name: 'doc-list', hidden: true, meta: { title: '资源管理', icon: '' }},
    //     {
    //       path: 'doc-add', component: () => import('@/views/doc/DocAdd'), name: 'doc-add', hidden: true, meta: { title: '添加资源', icon: '' }},
    //     {
    //       path: 'doc-edit', component: () => import('@/views/doc/DocEdit'), name: 'doc-edit', hidden: true, meta: { title: '编辑资源', icon: '' }}
    //   ]
    // }
  ]
}
export default schoolRouter
