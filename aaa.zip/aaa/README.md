# workshop

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

## 项目运行环境切换

```txt
项目默认是兵团的环境, 就是没有走登录的那一套流程, 直接从兵团跳过来, 如果想切换为单独的走自己的登录流程, 只需修改两处,  一是 appConfig.js 文件的配置,  二则是修改 store 里面的 env.js 文件 接入兵团的运行在本地应该是 locahost:8080/token=xxx/url
```
