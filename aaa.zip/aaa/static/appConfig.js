const isXJBT = true
// 接入兵团的
const baseXJBT = {
  app_isXJBT: true,
  app_basehost: 'http://xjbt.yx.nercel.cn', // 站点根网址
  app_indexurl: '/', // 网页主页链接
  app_login_path: 'http://xjbt.yx.nercel.cn/user/#/login', // 登录入口
  app_forget_path: 'http://xjbt.yx.nercel.cn/user/#/forget', // 找加密码入口
  app_register_path: 'http://xjbt.yx.nercel.cn/user/#/register', // 注册入口
  app_center_path: 'http://yx.nercel.cn/member/', // 个人中心
  app_letter_path: 'http://xjbt.yx.nercel.cn/member/#/letter', // 消息入口
  app_settings_path: 'http://yx.nercel.cn/member/#/settings', // 基本信息设置
  app_editpassword_path: 'http://xjbt.yx.nercel.cn/member/#/settings/editpassword', // 修改密码
  app_indexname: '主页', // 主页链接名
  app_webname: '教师研修培训服务', // 网站名称
  app_weblogo: './static/images/logo.svg', // 网站名称
  app_homePage: 'http://xjbt.yx.nercel.cn/index', // 门户首页
  app_upfile_path: 'http://xjbt.yx.nercel.cn/tool/file/upload' // 文件上传服务器地址
}
// 独立系统的
const base = {
  app_isXJBT: false,
  app_basehost: 'http://yx.nercel.cn/api', // 站点根网址
  app_indexurl: '/', // 网页主页链接
  app_login_path: 'http://api.yx.nercel.cn/user/#/login', // 登录入口
  app_forget_path: 'http://api.yx.nercel.cn/user/#/forget', // 找加密码入口
  app_register_path: 'http://api.yx.nercel.cn/user/#/register', // 注册入口
  app_center_path: 'http://yx.nercel.cn/member/', // 个人中心
  app_letter_path: 'http://api.yx.nercel.cn/member/#/letter', // 消息入口
  app_settings_path: 'http://yx.nercel.cn/member/#/settings', // 基本信息设置
  app_editpassword_path: 'http://api.yx.nercel.cn/member/#/settings/editpassword', // 修改密码
  app_indexname: '主页', // 主页链接名
  app_webname: '教师研修培训服务平台', // 网站名称
  app_weblogo: './static/images/logo.svg', // 网站名称
  app_homePage: 'http://yx.nercel.cn', // 门户首页
  app_upfile_path: 'http://yx.nercel.cn/api/zuul/tool/file/upload' // 文件上传服务器地址
}
const common = {
  app_webslogan: '登录入口',
  app_powerby: 'Copyright &copy; 2018-2020 HDGS. 华大国数 版权所有', // 网站版权信息
  app_keywords: '', // 站点默认关键字
  app_description: '', // 站点描述
  app_beian: '', // 网站备案号
  app_titleLength: 50, // 标题类字符长度
  app_disc: 5000, // 描述类字符长度
  app_distanceimg_path: '', // 远程图片地址 http://ps.test.nercel.cn
  app_up_path: 'http://gzf.test.nercel.cn/workshop/api/sourceHandle/getPicSource/',
  app_img_loading: './static/images/loading.svg', // 图片懒加载等待
  app_ddimg_width: '', // 缩略图默认宽度
  app_ddimg_height: '', // 缩略图默认高度
  app_imgtype: '', // 图片上传文件类型
  app_softtype: '', // 允许上传的软件类型
  app_mediatype: '', // 允许的多媒体文件类型
  app_max_face: '', // 会员上传头像大小限制(单位：KB)
  app_workshop_Logo: './static/images/workshopLogo.png', // 工作坊默认LOGO
  app_workshop_banner: './static/images/workshopCover.jpg', // 工作坊默认LOGO
  app_user_face_not: './static/images/photoUserNot.svg', // 暂无或加载出错用户头像
  app_thumbnail_not: './static/images/photoNot.svg', // 暂无或加载出错缩略图
  app_data_not: './static/images/dataNot.svg', // 暂无数据图片
  app_data_not_disc: '暂时没有找到您需要的数据，十分抱歉！您可以先看看别的' // 暂无数据的描述信息 $store.getters.appConfig.app_data_not_disc
}

// module.exports = Object.assign(base, common)
module.exports = Object.assign((isXJBT ? baseXJBT : base), common)
